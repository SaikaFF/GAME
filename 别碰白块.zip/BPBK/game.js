// JavaScript Document
var main = document.getElementById('main');
var go = document.getElementById('go');
var count = document.getElementById('count');
var cols = ['#1AAB8A','#E15650','#121B39','#80A84E'];

function getStyle(obj,arrt){
	return obj.currentStyle ? obj.cureentStyle[arrt]:getComputedStyle(obj,null)[arrt];
}

function cDiv(classname){
	var oDiv = document.createElement('div');
	var index = Math.floor(Math.random()*4);
	oDiv.className = classname;
	for(var j = 0;j<4;j++){
		var iDiv = document.createElement('div');
		oDiv.appendChild(iDiv);
	}
	if(main.children.length == 0){
		main.appendChild(oDiv);
	}else{
		main.insertBefore(oDiv,main.children[0]);
	}
	oDiv.children[index].style.backgroundColor = cols[index];
	oDiv.children[index].className = "i";
}
function move(obj){
	clearInterval(obj.timer);
	var speed = 5,num=0;
	obj.timer = setInterval(function(){
		var step = parseInt(getStyle(obj,'top'))+speed;
		obj.style.top = step+'px';
		if(parseInt(getStyle(obj,'top'))>=0){
			cDiv('row');
			obj.style.top =-150+'px';
		}
		if(obj.children.length == 6){
			for(var i = 0;i<4;i++){
				if(obj.children[obj.children.length-1].children[i].className == 'i'){
					obj.style.top = '-150px';
					count.innerHTML = '游戏结束，最高得分:'+num;
					clearInterval(obj.timer);
					go.children[0].innerHTML = 'Renew game';
					go.style.display = "block";
				}
			}
			obj.removeChild(obj.children[obj.children.length -1]);
		}
		obj.onmousedown = function(event){
			event = event||window.evnet;
			if((event.target?event.target:event.srcElement).className =='i'){
				(event.target?event.target:event.srcElement).style.backgroundColor = "#bbb";
				(event.target?event.target:event.srcElement).className = '';
				num++;
				count.innerHTML = '当前得分:' +num;
				bgm.play();
			}
			else{
				obj.style.top = 0;
				count.innerHTML = '游戏结束,最高得分:'+num;
				clearInterval(obj.timer);
				go.children[0].innerHTML = 'Renew game';
				go.style.display = "block";
			}
			if(num%10==0){
				speed++;
			}
		}
		obj.onmouseup=function(event){
			//bgm.pause();
		}
	},20)
}
go.children[0].onclick = function(){
	if(main.children.length){
		main.innerHTML='';
	}
	count.innerHTML = '游戏开始';
	this.parentNode.style.display = "none";
	move(main);
}
		