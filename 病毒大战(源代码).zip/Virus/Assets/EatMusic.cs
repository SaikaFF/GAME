﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EatMusic : MonoBehaviour {
    private AudioSource[] m_ArrayMusic;
    public static AudioSource Eat;
    public static AudioSource KuangBaoEat;
    public static AudioSource BGM;
    public static AudioSource KuangBaoBGM;
    public static AudioSource LevelUp;
	// Use this for initialization
	void Start () {
        m_ArrayMusic = gameObject.GetComponents<AudioSource>();
        Eat = m_ArrayMusic[0];
        KuangBaoEat = m_ArrayMusic[1];
        BGM = m_ArrayMusic[2];
        KuangBaoBGM = m_ArrayMusic[3];
        LevelUp = m_ArrayMusic[4];
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
