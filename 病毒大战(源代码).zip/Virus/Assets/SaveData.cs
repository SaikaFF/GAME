﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class SaveData : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        
	}
    //public void m_save()
    //{
    //    StreamWriter m_streamWrite = File.CreateText("Data.txt");
    //    m_streamWrite.WriteLine(PlayerMove.CoinTxt);
    //    m_streamWrite.WriteLine(PlayerMove.JingYanTxt);
    //    m_streamWrite.WriteLine(PlayerMove.JiETxt);
    //    m_streamWrite.WriteLine(PlayerMove.LevelTxt);
    //    m_streamWrite.WriteLine(PlayerMove.JETxt);
    //    m_streamWrite.Close();
    //}
    public void save()
    {
        PlayerPrefs.SetInt("CoinTxt", PlayerMove.CoinTxt);
        PlayerPrefs.SetFloat("JingYanTxt", PlayerMove.JingYanTxt);
        PlayerPrefs.SetFloat("JiETxt", PlayerMove.JiETxt);
        PlayerPrefs.SetFloat("LevelTxt", PlayerMove.LevelTxt);
        PlayerPrefs.SetFloat("JETxt", PlayerMove.JETxt);
        PlayerPrefs.SetFloat("MoveSpeed", PlayerMove.MoveSpeed);
        PlayerPrefs.SetInt("Aggressivity", PlayerMove.Aggressivity);
        PlayerPrefs.SetFloat("Speed", PlayerMove.Speed);
        Debug.Log("save");
    }
    public void delete()
    {
        PlayerPrefs.DeleteAll();
    }
}
