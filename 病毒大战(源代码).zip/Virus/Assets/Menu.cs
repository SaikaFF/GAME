﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour {
    public GameObject wenzi;
    public GameObject StartBtn;
    public GameObject HelpBtn;
    public GameObject BackBtn;
    public GameObject BackToMenuBtn;
    public GameObject QuitGameBtn;
    public GameObject MenuQuitGameBtn;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (PlayerMove.LevelTxt == 6)
        {
            BackToMenuBtn.SetActive(true);
            QuitGameBtn.SetActive(true);
        }
	}
    public void GameStart()
    {
        SceneManager.LoadScene("TTTEST");
        CellBuild.gg = 0;
    }
    public void Help()
    {
        wenzi.SetActive(true);
        StartBtn.SetActive(false);
        HelpBtn.SetActive(false);
        MenuQuitGameBtn.SetActive(false);
        BackBtn.SetActive(true);
    }
    public void Back()
    {
        wenzi.SetActive(false);
        StartBtn.SetActive(true);
        HelpBtn.SetActive(true);
        MenuQuitGameBtn.SetActive(true);
        BackBtn.SetActive(false);
    }
    public void BackToMenu()
    {
        SceneManager.LoadScene("Menu");
    }
    public void QuitGame()
    {
        #if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
        #else
                Application.Quit();
        #endif
    }
}
