﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HurtItem : MonoBehaviour
{
    private TextMesh textMesh;
    private float destoryTime;
    CellBuild CCell = null;
    public int Num;
    void Awake()
    {
        this.textMesh = this.GetComponent<TextMesh>();
    }
	// Use this for initialization
	void Start () {
        CCell = GameObject.Find("BuildCell").GetComponent<CellBuild>();
        Num = CellBuild.gg-31;
	}
	
	// Update is called once per frame
	void Update () {
        
        this.textMesh.text = CCell.life[Num].ToString();
	}
}
