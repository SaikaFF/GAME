﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CellMove : MonoBehaviour {
    float x;
    float z;
    private GameObject Playerr;
    float Speed = 0.3f;
	// Use this for initialization
	void Start () {
        x = Random.Range(-0.05f, 0.05f);
        z = Random.Range(-0.05f, 0.05f);
	}
	
	// Update is called once per frame
	void Update () {
        this.transform.position = new Vector3(this.transform.position.x, 0.5f, this.transform.position.z);
        Playerr = GameObject.Find("Player");
            this.transform.Translate(x, 0, z);
        if(PlayerMove.JETxt>0){
            this.transform.position = Vector3.MoveTowards(new Vector3(this.transform.position.x,0.5f,this.transform.position.z), new Vector3(Playerr.transform.position.x,0.5f,Playerr.transform.position.z), Speed);
        }
	}
    void OnCollisionEnter(Collision other)
    {
        if (other.collider.tag == "Wall")
        {
            this.transform.position = new Vector3(Random.Range(-40.0f, 73.0f), 0.5f, Random.Range(-40.0f, 66.0f));
        }
    }
}
