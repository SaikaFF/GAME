﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CellBuild : MonoBehaviour {
    int kk = 0;//敌人生成速度
    public static int gg = 0;//敌人数量
    public List<GameObject> CellList;//敌人数组
    public GameObject cell;//敌人
    public GameObject Bigcell;//敌人
    GameObject obj;//cell的定义
    GameObject Bigobj;//cell的定义
    public List<int> life;
	// Use this for initialization
	void Start () {
        //GameObject obj = GameObject.CreatePrimitive(PrimitiveType.Cube);
        //obj.GetComponent<MeshRenderer>().material.color = Color.blue;
	}
	
	// Update is called once per frame
	void Update () {
        kk++;
        if (gg < 40)
        {
            if (kk == 30)
            {
                if (gg < 30)
                {
                    obj = GameObject.Instantiate(cell);
                    CellList.Add(obj);
                    obj.layer = 8;
                    obj.tag = "cell";
                    obj.name = "cell";
                    obj.transform.position = new Vector3(Random.Range(-40.0f, 73.0f), 0.5f, Random.Range(-40f, 66.0f));
                    obj.GetComponent<MeshRenderer>().material.color = new Color(Random.Range(0f, 1f), Random.Range(0f, 1f), Random.Range(0f, 1f));
                }
                if (gg >= 30)
                {
                    Debug.Log(gg);
                    life.Add(10);
                    Bigobj = GameObject.Instantiate(Bigcell);
                   
                    CellList.Add(Bigobj);
                    Bigobj.layer = 9;
                    Bigobj.tag = "BigCell";
                    Bigobj.name = "BigCell";
                    Bigobj.transform.position = new Vector3(Random.Range(-40.0f, 73.0f), 0.5f, Random.Range(-40f, 66.0f));
                    Bigobj.GetComponent<MeshRenderer>().material.color = new Color(Random.Range(0f, 1f), Random.Range(0f, 1f), Random.Range(0f, 1f));
                }
                gg++;
                kk = 0;
            }
        }
	}
}
