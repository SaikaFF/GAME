﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Store : MonoBehaviour {
    private Image SpeedUpBtn;
    private Image AggressivityBtn;
    private Image BerserkValueBtn;
    public GameObject SpeedUp;
    public GameObject Aggressivity;
    public GameObject BerserkValue;
    int SpeedNum=0;
    int AggressivityNum=0;
	// Use this for initialization
	void Start () {
        SpeedUpBtn = SpeedUp.GetComponent<Image>();
        AggressivityBtn = Aggressivity.GetComponent<Image>();
        BerserkValueBtn = BerserkValue.GetComponent<Image>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public void Button()
    {
        if (SpeedUp.activeSelf)
        {
            SpeedUpBtn.gameObject.SetActive(false);
            AggressivityBtn.gameObject.SetActive(false);
            BerserkValueBtn.gameObject.SetActive(false);
        }
        else
        {
            SpeedUpBtn.gameObject.SetActive(true);
            AggressivityBtn.gameObject.SetActive(true);
            BerserkValueBtn.gameObject.SetActive(true);
        }
    }
    public void BuySpeed()
    {
        if (PlayerMove.CoinTxt >= 1000 && SpeedNum<6)
        {
            PlayerMove.MoveSpeed += 1.2f;
            PlayerMove.Speed += 0.02f;
            CameraFollow.CameraSpeed += 10;
            PlayerMove.CoinTxt -= 1000;
            SpeedNum++;
        }
    }
    public void BuyAggressivity()
    {
        if (PlayerMove.CoinTxt >= 1000 && AggressivityNum<9)
        {
            PlayerMove.Aggressivity += 1;
            PlayerMove.CoinTxt -= 1000;
            AggressivityNum++;
        }
    }
    public void BuyBerserkValue()
    {
        if (PlayerMove.CoinTxt >= 500)
        {
            PlayerMove.JiETxt += 40f;
            PlayerMove.CoinTxt -= 500;
        }

    }
}
