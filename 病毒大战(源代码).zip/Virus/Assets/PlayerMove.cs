﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class PlayerMove : MonoBehaviour {
    private float StartSpeed=0f;//开始速度 
    public static float MoveSpeed = 6f;//移动速度
    public static int Aggressivity = 1;//攻击力
    private Ray ray;//定义射线
    private RaycastHit hit = new RaycastHit();
    private Vector3 EndPosition;//移动结束（鼠标点击）的位置
    public static float Speed = 0.15f;//Idle速度
    public Text Coin;//金币文本
    public Text AggressivityTxt;//攻击力文本
    public Text MoveSpeedTxt;//移动速度文本
    public Text SpeedTxt;//Idle速度文本
    public static int CoinTxt = 0;//金币数值
    public Text Level;//等级文本
    public static float JingYanTxt = 0;//经验数值
    public static float JiETxt = 0;//饥饿数值
    public static float LevelTxt = 1;//等级数值
    public static float JETxt = 0;//饥饿状态
    public Image JY;//经验条
    public Image JE;//饥饿条
    float MaxJingYanTxt;//最大经验值
    float MaxJiETxt;//最大饥饿值
    int minDistance;//最小距离
    int zz = 0;//idle启动时间
    int jj = 0;//饥饿启动时间
    CellBuild CCell = null;
	// Use this for initialization
	void Start () {
        CCell = GameObject.Find("BuildCell").GetComponent<CellBuild>();
        MoveSpeed = 6f;
        Aggressivity = 1;
        Speed = 0.15f;
        CoinTxt = 0;
        JingYanTxt = 0;
        JiETxt = 0;
        LevelTxt = 1;
        JETxt = 0;
	}
	
	// Update is called once per frame
	void Update () {
        this.transform.position = new Vector3(this.transform.position.x, 0.5f, this.transform.position.z);
        if (Input.GetMouseButtonDown(0) && JETxt != 1)
        {
            if (EventSystem.current.currentSelectedGameObject != null)
            { }
            else
            {
                ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                Physics.Raycast(ray, out hit);
                EndPosition = hit.point;
                EndPosition.y = 0.5f;
                transform.LookAt(EndPosition);
                StartSpeed = MoveSpeed;
                zz = 0;
            }
        } 
        if (Vector3.Distance(transform.position, hit.point) < 1f) 
        {
            StartSpeed = 0;
            zz++;
        }
        transform.Translate(transform.forward * StartSpeed * Time.deltaTime, Space.World);
        if (StartSpeed == 0 && zz >= 60)
        {
            ZZ();
            this.transform.position = Vector3.MoveTowards(new Vector3(this.transform.position.x,0.5f,this.transform.position.z),new Vector3(CCell.CellList[minDistance].transform.position.x,0.5f,CCell.CellList[minDistance].transform.position.z),Speed);
        }
        Coin.text = "" + CoinTxt;
        AggressivityTxt.text = "" + Aggressivity;
        MoveSpeedTxt.text = "" + MoveSpeed;
        SpeedTxt.text = "" + Speed;
        JY.fillAmount = JingYanTxt / MaxJingYanTxt;
        JE.fillAmount = JiETxt/MaxJiETxt;
        Level.text = "" + LevelTxt;
        if (JY.fillAmount == 1 && LevelTxt<6)
        {
            EatMusic.LevelUp.Play();
            LevelTxt++;
            JingYanTxt = 0;
        }
        if (JE.fillAmount == 1)
        {
            EatMusic.KuangBaoBGM.Play();
            JETxt=1;
            JiETxt = 0;
        }
        if (JETxt == 1) { jj++; if (jj == 300) { JETxt = 0; jj = 0; } }
        if (LevelTxt == 1) { MaxJingYanTxt = 100; MaxJiETxt = 20; }
        if (LevelTxt == 2) { MaxJingYanTxt = 260; MaxJiETxt = 40; }
        if (LevelTxt == 3) { MaxJingYanTxt = 380; MaxJiETxt = 80; }
        if (LevelTxt == 4) { MaxJingYanTxt = 510; MaxJiETxt = 90; }
        if (LevelTxt == 5) { MaxJingYanTxt = 600; MaxJiETxt = 110; }
        if (LevelTxt == 6) { MaxJingYanTxt = 800; MaxJiETxt = 120; }
	}
    void ZZ()
    {
        float distance = 100f;
        for (int i = 0; i < CCell.CellList.Count; i++)
        {
            if (Vector3.Distance(this.transform.position, CCell.CellList[i].transform.position) < distance)
            {
                distance = Vector3.Distance(this.transform.position, CCell.CellList[i].transform.position);
                minDistance = i;
            }
        }
    }
    void OnCollisionStay(Collision other)
    {
        if (other.collider.tag == "cell")
        {
            other.transform.position = new Vector3(Random.Range(-40.0f, 73.0f), 0.5f, Random.Range(-40.0f, 66.0f));
            if (JETxt != 1)
            {
                if (LevelTxt == 1) { JingYanTxt += 5f; JiETxt += 2f; CoinTxt += 30; }
                if (LevelTxt == 2) { JingYanTxt += 8f; JiETxt += 2f; CoinTxt += 30; }
                if (LevelTxt == 3) { JingYanTxt += 10f; JiETxt += 3f; CoinTxt += 30; }
                if (LevelTxt == 4) { JingYanTxt += 12f; JiETxt += 3f; CoinTxt += 30; }
                if (LevelTxt == 5) { JingYanTxt += 18f; JiETxt += 5f; CoinTxt += 30; }
                if (LevelTxt == 6) { JingYanTxt += 20f; JiETxt += 5f; CoinTxt += 30; }
                EatMusic.Eat.Play();
            }
            if (JETxt == 1)
            {
                if (LevelTxt == 1) { JingYanTxt += 5f; JiETxt += 0f; CoinTxt += 30; }
                if (LevelTxt == 2) { JingYanTxt += 8f; JiETxt += 0f; CoinTxt += 30; }
                if (LevelTxt == 3) { JingYanTxt += 10f; JiETxt += 0f; CoinTxt += 30; }
                if (LevelTxt == 4) { JingYanTxt += 12f; JiETxt += 0f; CoinTxt += 30; }
                if (LevelTxt == 5) { JingYanTxt += 18f; JiETxt += 0f; CoinTxt += 30; }
                if (LevelTxt == 6) { JingYanTxt += 20f; JiETxt += 0f; CoinTxt += 30; }
                EatMusic.KuangBaoEat.Play();
            }
        }
        if (other.collider.tag == "BigCell")
        {
            if (JETxt != 1)
            {
                int find = 0;
                int who = 0;
                for (int j = 0; j < 10; j++)
                {
                    if (other.gameObject == CCell.CellList[j + 30])
                    {
                        who = j;
                        find = 1;
                        break;
                    }
                }
                if (find == 1)
                {
                    CCell.life[who] -= Aggressivity;
                    if (CCell.life[who] <= 0)
                    {
                        other.transform.position = new Vector3(Random.Range(-40.0f, 73.0f), 0.5f, Random.Range(-40.0f, 66.0f));
                        CCell.life[who] = 10;
                        if (LevelTxt == 1) { JingYanTxt += 5f; JiETxt += 2f; CoinTxt += 30; }
                        if (LevelTxt == 2) { JingYanTxt += 8f; JiETxt += 2f; CoinTxt += 30; }
                        if (LevelTxt == 3) { JingYanTxt += 10f; JiETxt += 3f; CoinTxt += 30; }
                        if (LevelTxt == 4) { JingYanTxt += 12f; JiETxt += 3f; CoinTxt += 30; }
                        if (LevelTxt == 5) { JingYanTxt += 18f; JiETxt += 5f; CoinTxt += 30; }
                        if (LevelTxt == 6) { JingYanTxt += 20f; JiETxt += 5f; CoinTxt += 30; }
                    }
                }
                EatMusic.Eat.Play();
                other.gameObject.transform.localPosition = Vector3.MoveTowards(new Vector3(other.gameObject.transform.position.x, 0.5f, other.gameObject.transform.position.z), new Vector3(this.transform.position.x, 0.5f, this.transform.position.z), -1f);
            }
            //if (JETxt != 1)
            //{
            //    EatMusic.Eat.Play();
            //    other.gameObject.transform.localPosition = Vector3.MoveTowards(new Vector3(other.gameObject.transform.position.x, 0.5f, other.gameObject.transform.position.z), new Vector3(this.transform.position.x, 0.5f, this.transform.position.z), -1f);
            //}
            if (JETxt == 1)
            {
                if (LevelTxt == 1) { JingYanTxt += 5f; JiETxt += 0f; CoinTxt += 30; }
                if (LevelTxt == 2) { JingYanTxt += 8f; JiETxt += 0f; CoinTxt += 30; }
                if (LevelTxt == 3) { JingYanTxt += 10f; JiETxt += 0f; CoinTxt += 30; }
                if (LevelTxt == 4) { JingYanTxt += 12f; JiETxt += 0f; CoinTxt += 30; }
                if (LevelTxt == 5) { JingYanTxt += 18f; JiETxt += 0f; CoinTxt += 30; }
                if (LevelTxt == 6) { JingYanTxt += 20f; JiETxt += 0f; CoinTxt += 30; }
                other.transform.position = new Vector3(Random.Range(-40.0f, 73.0f), 0.5f, Random.Range(-40.0f, 66.0f));
                EatMusic.KuangBaoEat.Play();
            }
        }
        if (other.collider.tag == "Wall")
        {
            this.transform.position = new Vector3(this.transform.position.x,0.5f,this.transform.position.z);
        }
    }
}
