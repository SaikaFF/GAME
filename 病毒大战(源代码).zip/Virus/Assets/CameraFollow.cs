﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {
    private Transform m_Transfrom;
    private Transform m_PlayerTransfrom;
    public static int CameraSpeed=10;
    int i;
	// Use this for initialization
	void Start () {
        m_Transfrom = gameObject.GetComponent<Transform>();
        m_PlayerTransfrom = GameObject.FindGameObjectsWithTag("Player")[0].GetComponent<Transform>();
        Screen.SetResolution(1080, 1960, false);
	}
	
	// Update is called once per frame
	void Update () {
        if (PlayerMove.JETxt == 1)
        {
            this.transform.position=new Vector3(m_PlayerTransfrom.transform.position.x + Random.Range(-0.5f, 0.5f), 20, m_PlayerTransfrom.transform.position.z + Random.Range(-0.5f, 0.5f));
        }
	}
    void LateUpdate()
    {
        Vector3 V = new Vector3(m_PlayerTransfrom.position.x * 0.95f, 20, m_PlayerTransfrom.position.z * 0.95f);
        m_Transfrom.position = Vector3.MoveTowards(m_Transfrom.position, V, Time.deltaTime * CameraSpeed);
    }
}
