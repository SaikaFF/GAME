﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class ReadData : MonoBehaviour {

	// Use this for initialization
	void Start () {
        //if (File.Exists("Data.txt"))
        //{
        //    StreamReader m_streamReader = File.OpenText("Data.txt");
        //    PlayerMove.CoinTxt = int.Parse(m_streamReader.ReadLine());
        //    PlayerMove.JingYanTxt = int.Parse(m_streamReader.ReadLine());
        //    PlayerMove.JiETxt = int.Parse(m_streamReader.ReadLine());
        //    PlayerMove.LevelTxt = int.Parse(m_streamReader.ReadLine());
        //    PlayerMove.JETxt = int.Parse(m_streamReader.ReadLine());
        //    m_streamReader.Close();
        //}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public void Read()
    {
        if (PlayerPrefs.HasKey("CoinTxt"))
            PlayerMove.CoinTxt = PlayerPrefs.GetInt("CoinTxt");
        if(PlayerPrefs.HasKey("JingYanTxt"))
            PlayerMove.JingYanTxt = PlayerPrefs.GetFloat("JingYanTxt");
        if (PlayerPrefs.HasKey("JiETxt"))
            PlayerMove.JiETxt = PlayerPrefs.GetFloat("JiETxt");
        if (PlayerPrefs.HasKey("LevelTxt"))
            PlayerMove.LevelTxt = PlayerPrefs.GetFloat("LevelTxt");
        if (PlayerPrefs.HasKey("JETxt"))
            PlayerMove.JETxt = PlayerPrefs.GetFloat("JETxt");
        if (PlayerPrefs.HasKey("MoveSpeed"))
            PlayerMove.MoveSpeed = PlayerPrefs.GetFloat("MoveSpeed");
        if (PlayerPrefs.HasKey("Aggressivity"))
            PlayerMove.Aggressivity = PlayerPrefs.GetInt("Aggressivity");
        if (PlayerPrefs.HasKey("Speed"))
            PlayerMove.Speed = PlayerPrefs.GetFloat("Speed");
            Debug.Log("Read");
    }
}
