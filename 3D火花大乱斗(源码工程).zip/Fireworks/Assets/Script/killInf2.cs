﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class killInf2 : MonoBehaviour {
    int deleteTime = 0;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        deleteTime++;
        if (deleteTime > 900)
        {
            Destroy(this.gameObject);
        }
	}
}
