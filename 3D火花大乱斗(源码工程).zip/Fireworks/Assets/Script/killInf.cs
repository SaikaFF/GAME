﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class killInf : MonoBehaviour
{
    float speed = 20.0f;
    int deleteTime = 0;
    // Use this for initialization
    void Start()
    {
        this.GetComponent<RectTransform>().anchoredPosition = new Vector2(-848f, 856f);
    }

    // Update is called once per frame
    void Update()
    {
        deleteTime++;
        if (deleteTime > 1000)
        {
            Destroy(this.gameObject);
        }
        this.GetComponent<RectTransform>().Translate(new Vector2(speed, 0));
        if (this.GetComponent<RectTransform>().anchoredPosition.x > -50f)
        {
            speed = 1f;
        }
        if (this.GetComponent<RectTransform>().anchoredPosition.x > 100f)
        {
            speed = 20f;
        }
    }
}
