﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class groundfireworks : MonoBehaviour
{
    public List<GameObject> groundALLFireworks;//所有地面烟花
    public GameObject groundFireworks;//烟花预制体

    public List<GameObject> groundALLRocket;//所有地面火箭
    public GameObject groundRocket;//火箭预制体

    public List<GameObject> groundALLCoins;//所有地面金币箱
    public GameObject groundCoins;//金币箱预制体

    public List<GameObject> groundALLEXP;//所有地面经验道具
    public GameObject groundEXP;//经验道具预制体

    int rocketTime = 0;//火箭生成时间
    int coinsTime = 0;//金币箱生成时间
    int EXPTime = 0;//经验道具生成时间
    //GameObject groundFireworksa;
	// Use this for initialization
	void Start () {
        GameObject t_groundFireworks;
        for (int i = 0; i < 150; i++)
        {
            t_groundFireworks = GameObject.Instantiate(groundFireworks);
            t_groundFireworks.transform.position = new Vector3(Random.Range(-95.0f, 95.0f), 0.5f, Random.Range(-95.0f, 95.0f));
            t_groundFireworks.tag = "Fireworks";
            t_groundFireworks.gameObject.layer = 8;
            groundALLFireworks.Add(t_groundFireworks);
        }
	}

    // Update is called once per frame
    void Update()
    {
        rocketTime++;
        if (rocketTime > 300)
        {
            rocketTime = 0;
            GameObject t_groundRocket;
            t_groundRocket = GameObject.Instantiate(groundRocket);
            t_groundRocket.transform.position = new Vector3(Random.Range(-95.0f, 95.0f), 0.5f, Random.Range(-95.0f, 95.0f));
            t_groundRocket.tag = "Rocket";
            groundALLRocket.Add(t_groundRocket);
        }

        coinsTime++;
        if (coinsTime > 300)
        {
            coinsTime = 0;
            GameObject t_groundCoins;
            t_groundCoins = GameObject.Instantiate(groundCoins);
            t_groundCoins.transform.position = new Vector3(Random.Range(-95.0f, 95.0f), 0.5f, Random.Range(-95.0f, 95.0f));
            t_groundCoins.tag = "Coins";
            groundALLCoins.Add(t_groundCoins);
        }

        EXPTime++;
        if (EXPTime > 300)
        {
            EXPTime = 0;
            GameObject t_groundEXP;
            t_groundEXP = GameObject.Instantiate(groundEXP);
            t_groundEXP.transform.position = new Vector3(Random.Range(-95.0f, 95.0f), 0.5f, Random.Range(-95.0f, 95.0f));
            t_groundEXP.tag = "EXP";
            groundALLEXP.Add(t_groundEXP);
        }
	}
}
