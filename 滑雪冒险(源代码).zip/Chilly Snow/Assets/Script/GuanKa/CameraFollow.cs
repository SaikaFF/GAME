﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    private Transform m_Transfrom;
    private Transform m_PlayerTransfrom;
    public static float CameraSpeed = 1f;
	// Use this for initialization
	void Start () {
        m_Transfrom = gameObject.GetComponent<Transform>();
        m_PlayerTransfrom = GameObject.FindGameObjectsWithTag("Player")[0].GetComponent<Transform>();
        Screen.SetResolution(1080, 1960, false);
	}
	
	// Update is called once per frame
	void Update () {
        
	}
    void LateUpdate()
    {
        Vector3 V = new Vector3(m_PlayerTransfrom.position.x + 6f, 30, 0);
        m_Transfrom.position = Vector3.MoveTowards(m_Transfrom.position, V, CameraSpeed);
    }
}
