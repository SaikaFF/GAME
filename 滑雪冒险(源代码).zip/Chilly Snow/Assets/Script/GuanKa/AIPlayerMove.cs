﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIPlayerMove : MonoBehaviour {
    public float MoveSpeed = 0f;
    public float Turn = 0.1f;
    public GameObject TeXiao;
    int Zhuang = 0;
    int flag = 0;
    PlayerMove Player;
	// Use this for initialization
	void Start () {
        Player = GameObject.Find("Player").GetComponent<PlayerMove>();
        Turn = 0.1f;
	}
	
	// Update is called once per frame
	void Update () {
        if (UIControl.Win == 1 || Player.GG == 1)
        {
            MoveSpeed = 0;
            Turn = 0;
        }
        if (UIControl.WuJin == 1)
        {
            this.gameObject.SetActive(false);
        }
        if (UIControl.GuanKa == 1 || UIControl.GuanKa == 2)
        {
            this.gameObject.SetActive(true);
        }
        if (Player.sttt == 1)
        {
            this.transform.Translate(new Vector3(MoveSpeed, 0, Turn));
        }
        if (Player.sttt == 1 && Zhuang != 1)
        {
            MoveSpeed = 0.25f;
            if (this.transform.position.z >= 11f)
            {
                flag = 0;
            }
            if (this.transform.position.z <= -11f)
            {
                flag = 1;
            }
            if (flag == 0) { Turn = -0.2f; }
            if (flag == 1) { Turn = 0.2f; }
        }
        if (Player.sttt == 1 && this.transform.position.x <= Player.transform.position.x - 30f && Zhuang == 1)
        {
            Zhuang = 0;
            this.transform.position = new Vector3(Player.transform.position.x - 10f, 0.5f, Random.Range(-10f, 11f));
            this.GetComponent<MeshRenderer>().material.color = new Color(255, 255, 255);
        }
        if (Player.ZhuangTai == 1)
        {
            TeXiao.gameObject.SetActive(true);
        }
        if (Player.ZhuangTai != 1)
        {
            TeXiao.gameObject.SetActive(false);
        }
        if (this.transform.position.x >= 600)
        {
            Player.GG = 1;
        }
        if (Zhuang == 1)
        {
            this.GetComponent<MeshRenderer>().material.color = new Color(255, 0, 0);
        }
	}
    void OnCollisionStay(Collision other)
    {
        if (other.collider.tag == "Player")
        {
            if (UIControl.Win != 1)
            {
                if (Player.ZhuangTai != 1 && Player.WuDiZhuangTai != 1)
                {
                    MoveSpeed = 0f;
                    Turn = 0;
                    Zhuang = 1;
                    Player.life--;
                    Player.MoveSpeed = 0.1f;
                    Player.Turn = 0f;
                    Player.KuangBao = 0f;
                    Player.ZhuangTree = 1;
                }
            }
        }
        if (other.collider.tag == "Obstacle")
        {
            MoveSpeed = 0f;
            Turn = 0;
            Zhuang = 1;
        }
        if (other.collider.tag == "AI")
        {
            MoveSpeed = 0f;
            Turn = 0;
            Zhuang = 1;
        }
        if (other.collider.tag == "AIPlayer")
        {
            MoveSpeed = 0f;
            Turn = 0;
            Zhuang = 1;
        }
    }
}
