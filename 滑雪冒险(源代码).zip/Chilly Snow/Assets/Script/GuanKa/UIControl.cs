﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UIControl : MonoBehaviour
{
    PlayerMove Player = null;
    public Text GameOverText;
    public Text WinOneText;
    public Image OneNextBtn;
    public Image TryAgainBtn;
    public Image BackBtn;
    public Text ScoreText;
    public Text LfieText;
    public Image Angry;
    public GameObject EndPoint;
    float KuangBaoZhi = 0;
    float KuangBaoTime = 0;
    public GameObject Ground;
    public static int WuJin = 0;
    public static float Win = 0;
    public static int GuanKa = 1;
    public Text GUANKATXT;
    public Image JinDuTiao;
    public Image JinDuKuang;
    public Image JinDu;
    public Text ZuiGaoFen;
    public static float GaoFen = 0;
    float zhi = 0;
    public GameObject wallOne;
    public GameObject wallTwo;
	// Use this for initialization
	void Start () {
        Player = GameObject.Find("Player").GetComponent<PlayerMove>();
        EndPoint.transform.position = new Vector3(599f, EndPoint.transform.position.y, EndPoint.transform.position.z);
        Ground.transform.position = new Vector3(-1.5f, Ground.transform.position.y, Ground.transform.position.z);
        wallOne.transform.position = new Vector3(3f, wallOne.transform.position.y, wallOne.transform.position.z);
        wallTwo.transform.position = new Vector3(3f, wallTwo.transform.position.y, wallTwo.transform.position.z);
	}
	
	// Update is called once per frame
	void Update () {
        if (WuJin == 1)
        {
            if ((PlayerMove.Score + ScoreAdd.ScoreAdddd) > GaoFen)
            {
                GaoFen = PlayerMove.Score + ScoreAdd.ScoreAdddd;
            }
            ZuiGaoFen.text = "最高分:" + GaoFen;
            ZuiGaoFen.gameObject.SetActive(true);
            JinDuTiao.gameObject.SetActive(false);
            JinDuKuang.gameObject.SetActive(false);
            JinDu.gameObject.SetActive(false);
        }
        if (WuJin != 1)
        {
            zhi = Player.transform.position.x + 560f;
            JinDuTiao.fillAmount = zhi / 1160f;
            JinDuTiao.gameObject.SetActive(true);
            JinDuKuang.gameObject.SetActive(true);
            JinDu.gameObject.SetActive(true);
            ZuiGaoFen.gameObject.SetActive(false);
        }
        if (GuanKa == 1)
        {
            GUANKATXT.gameObject.SetActive(true);
            GUANKATXT.text = "第一关";
        }
        if (GuanKa == 2)
        {
            GUANKATXT.gameObject.SetActive(true);
            GUANKATXT.text = "第二关";
        }
        if (WuJin == 1)
        {
            GUANKATXT.gameObject.SetActive(false);
        }
        ScoreText.text = "" + (PlayerMove.Score + ScoreAdd.ScoreAdddd);
        if(Player.ZhuangTai != 1)
        {
            KuangBaoZhi = Player.KuangBao;
            Angry.fillAmount = KuangBaoZhi;
        }
        if (Angry.fillAmount == 1)
        {
            Player.ZhuangTai = 1;
            Player.TeXiao.gameObject.SetActive(true);
            Player.GetComponent<MeshRenderer>().material.color = new Color(255, 132, 0);
        }
        if (Player.ZhuangTai == 1)
        {
            KuangBaoTime++;
            if (KuangBaoTime >= 3) { Angry.fillAmount -= 0.01f; KuangBaoTime = 0; }
            if (Angry.fillAmount == 0) 
            { 
                KuangBaoTime = 0; 
                Player.ZhuangTai = 0;
                Player.GetComponent<MeshRenderer>().material.color = new Color(255, 255, 255);
                Player.TeXiao.gameObject.SetActive(false);
                KuangBaoZhi = 0;
                Player.KuangBao = 0;
            }
        }
        if (Player.GG == 1 || Player.life <= 0)
        {
            GameOverText.gameObject.SetActive(true);
            TryAgainBtn.gameObject.SetActive(true);
            BackBtn.gameObject.SetActive(true);
            Player.MoveSpeed = 0;
            Player.Turn = 0;
            Player.GG = 1;
            Player.TeXiao.gameObject.SetActive(false);
            PlayerPrefs.SetFloat("ZuiGaoFenTxt", UIControl.GaoFen);
        }
        if (Player.transform.position.x >= 600 && WuJin == 0)
        {
            WinOneText.gameObject.SetActive(true);
            TryAgainBtn.gameObject.SetActive(true);
            BackBtn.gameObject.SetActive(true);
            if (GuanKa == 1) { OneNextBtn.gameObject.SetActive(true); }
            Player.MoveSpeed = 0;
            Player.Turn = 0;
            Win = 1;
        }
        if (WuJin == 1 && Vector3.Distance(Player.transform.position,EndPoint.transform.position) <= 50f)
        {
            ObstacleSetting.ObstacleNum = 0;
            ObstacleSetting.ObstacleNumOne = 30;
            ObstacleSetting.ObstacleNumTwo = 100;
            ObstacleSetting.ObstacleNumThree = 200;
            ObstacleSetting.ObstacleNumFour = 300;
            ObstacleSetting.ObstacleNumFive = 400;
            ObstacleSetting.JuLi += 500f;
            EndPoint.transform.position = new Vector3(EndPoint.transform.position.x + 500f, EndPoint.transform.position.y, EndPoint.transform.position.z);
            Ground.transform.position = new Vector3(Ground.transform.position.x + 500f, Ground.transform.position.y, Ground.transform.position.z);
            wallOne.transform.position = new Vector3(wallOne.transform.position.x + 500f, wallOne.transform.position.y, wallOne.transform.position.z);
            wallTwo.transform.position = new Vector3(wallTwo.transform.position.x + 500f, wallTwo.transform.position.y, wallTwo.transform.position.z);
        }
        LfieText.text = "" + Player.life;
	}
    public void TryAgain()
    {
        SceneManager.LoadScene("GameSceneOne");
        if (GuanKa == 1) { GuanKa = 1; }
        if (GuanKa == 2) { GuanKa = 2; }
        if (WuJin == 1) { WuJin = 1; }
        PlayerMove.Score = 0;
        ScoreAdd.ScoreAdddd = 0;
        Win = 0;
    }
    public void Back()
    {
        SceneManager.LoadScene("Menu");
    }
    public void next()
    {
        SceneManager.LoadScene("GameSceneOne");
        GuanKa = 2;
        PlayerMove.Score = 0;
        ScoreAdd.ScoreAdddd = 0;
        Win = 0;
    }
}
