﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIMove : MonoBehaviour {
    public float MoveSpeed = 0f;
    public float Turn = 0f;
    public GameObject TeXiao;
    int Zhuang = 0;
    PlayerMove Player;
	// Use this for initialization
	void Start () {
        Player = GameObject.Find("Player").GetComponent<PlayerMove>();
	}
	
	// Update is called once per frame
	void Update () {
        if (UIControl.GuanKa == 1 || UIControl.WuJin == 1)
        {
            this.gameObject.SetActive(false);
        }
        if (UIControl.GuanKa == 2)
        {
            this.gameObject.SetActive(true);
        }
        this.transform.Translate(new Vector3(MoveSpeed, 0, 0));
        if (Player.sttt == 1 && Zhuang != 1)
        {
            MoveSpeed = 0.3f;
        }
        if (Player.sttt == 1 && this.transform.position.x <= Player.transform.position.x - 30f || this.transform.position.x >= Player.transform.position.x + 50f)
        {
            Zhuang = 0;
            this.transform.position = new Vector3(Player.transform.position.x - 10f, 0.5f, Random.Range(-10f, 11f));
            TeXiao.gameObject.SetActive(true);
        }
	}
    void OnCollisionStay(Collision other)
    {
        if (other.collider.tag == "Player")
        {
            if (Player.ZhuangTai != 1 && Player.WuDiZhuangTai != 1)
            {
                Player.life--;
                Player.MoveSpeed = 0.1f;
                Player.Turn = 0f;
                Player.KuangBao = 0f;
                Player.ZhuangTree = 1;
            }
            MoveSpeed = 0f;
            Zhuang = 1;
            TeXiao.gameObject.SetActive(false);
        }
        if (other.collider.tag == "Obstacle")
        {
            MoveSpeed = 0f;
            Zhuang = 1;
            TeXiao.gameObject.SetActive(false);
        }
        if (other.collider.tag == "AIPlayer")
        {
            MoveSpeed = 0f;
            Zhuang = 1;
            TeXiao.gameObject.SetActive(false);
        }
    }
}
