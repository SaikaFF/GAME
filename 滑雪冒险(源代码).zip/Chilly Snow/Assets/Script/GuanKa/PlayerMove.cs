﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour {
    int flag = 0;
    float ScoreTime = 0;
    public static float Score;
    public float MoveSpeed = 0f;
    public float Turn = 0f;
    public float GG = 0;
    public float ZhuangTai = 0;
    public float life = 10;
    public float KuangBao;
    float WuDiTime = 0;
    public float WuDiZhuangTai = 0;
    public float ZhuangTree = 0;
    public GameObject TeXiao;
    public int sttt = 0;
	// Use this for initialization
	void Start () {
        UIControl.Win = 0;
        if (PlayerPrefs.HasKey("ZuiGaoFenTxt"))
        { UIControl.GaoFen = PlayerPrefs.GetFloat("ZuiGaoFenTxt"); }
	}
	
	// Update is called once per frame
	void Update () {
        this.transform.position = new Vector3(this.transform.position.x, 0.5f, this.transform.position.z);
        this.transform.Translate(new Vector3(MoveSpeed,0,Turn));
        if (Input.GetMouseButtonDown(0) && GG != 1 && UIControl.Win != 1)
        {
            sttt = 1;
            if (ZhuangTai == 0)
            {
                MoveSpeed = 0.2f;
                if (flag == 0) { flag = 1; }
                else if (flag == 1) { flag = 0; }
            }
            if (ZhuangTai == 1)
            {
                MoveSpeed = 0.4f;
                if (flag == 0) { flag = 1;}
                else if (flag == 1) { flag = 0;}
            }
        }
        if (flag == 1 && Turn <= 0.1f && sttt == 1 && ZhuangTai == 0)
        {
            Turn += 0.01f;
        }
        if (flag == 0 && Turn >= -0.1f && sttt == 1 && ZhuangTai == 0)
        {
            Turn -= 0.01f;
        }
        if (flag == 1 && Turn <= 0.2f && sttt == 1 && ZhuangTai == 1)
        {
            Turn += 0.01f;
        }
        if (flag == 0 && Turn >= -0.2f && sttt == 1 && ZhuangTai == 1)
        {
            Turn -= 0.01f;
        }
        ScoreTime++;
        if (ZhuangTai == 0)
        {
            if (MoveSpeed != 0 && ScoreTime >= 20 && GG != 1)
            {
                Score++;
                KuangBao += 0.015f;
                ScoreTime = 0;
            }
        }
        if (ZhuangTai == 1)
        {
            if (MoveSpeed != 0 && ScoreTime >= 10 && GG != 1)
            {
                Score++;
                ScoreTime = 0;
            }
        }
        if (this.transform.position.z >= 11 )
        {
            GG = 1;
        }
        if (this.transform.position.z <= -11)
        {
            GG = 1;
        }
        if (ZhuangTree == 1)
        {
            WuDiZhuangTai = 1;
            WuDiTime++;
            this.GetComponent<MeshRenderer>().material.color = new Color(255, 0, 0);
            if (WuDiTime >= 120)
            {
                WuDiZhuangTai = 0;
                WuDiTime = 0;
                ZhuangTree = 0;
                this.GetComponent<MeshRenderer>().material.color = new Color(255, 255, 255);
            }
        }
	}
    void OnCollisionStay(Collision other)
    {
        if (other.collider.tag == "Obstacle" && ZhuangTai != 1)
        {
            ZhuangTree = 1;
            KuangBao -= KuangBao/4;
            if (ZhuangTai != 1 && WuDiZhuangTai != 1) { life--; }
            this.transform.position = new Vector3(this.transform.position.x - 3f, 0.5f, this.transform.position.z);
            if (life <= 0)
            {
                GG = 1;
            }
        }
    }
}
