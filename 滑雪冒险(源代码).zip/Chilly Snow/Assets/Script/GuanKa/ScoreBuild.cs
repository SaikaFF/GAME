﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreBuild : MonoBehaviour {
    public GameObject PopupDamage;
    PlayerMove Player = null;
    float ScoreTime = 0;
	// Use this for initialization
	void Start () {
        Player = GameObject.Find("Player").GetComponent<PlayerMove>();
	}
	
	// Update is called once per frame
	void Update () {
        if (Vector3.Distance(Player.transform.position,this.transform.position) < 2.5f && Player.GG != 1 && ScoreTime == 0)
            {
                GameObject mObject = (GameObject)Instantiate(PopupDamage, transform.position, Quaternion.identity);
                mObject.GetComponent<ScoreItem>().Value = "+" + ScoreAdd.Score;
                Player.KuangBao += 0.05f;
                ScoreTime = 1;
            }
	}
}
