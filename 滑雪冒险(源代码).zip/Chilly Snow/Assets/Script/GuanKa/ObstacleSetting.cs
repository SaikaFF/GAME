﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleSetting : MonoBehaviour {
    public GameObject Obstacle;
    public static int ObstacleNum = 0;
    public static int ObstacleNumOne = 30;
    public static int ObstacleNumTwo = 100;
    public static int ObstacleNumThree = 200;
    public static int ObstacleNumFour = 300;
    public static int ObstacleNumFive = 400;
    public static float JuLi = 0;
    GameObject obj;
    PlayerMove Player = null;
	// Use this for initialization
	void Start () {
        Player = GameObject.Find("Player").GetComponent<PlayerMove>();
        ObstacleNum = 0;
        ObstacleNumOne = 30;
        ObstacleNumTwo = 100;
        ObstacleNumThree = 200;
        ObstacleNumFour = 300;
        ObstacleNumFive = 400;
        JuLi = 0;
	}
	
	// Update is called once per frame
	void Update () {
        if (ObstacleNum <= 30) { ObstacleNum++; }
        if (ObstacleNum >= 0 && ObstacleNum < 30)
        {
            obj = GameObject.Instantiate(Obstacle);
            obj.layer = 8;
            obj.tag = "Obstacle";
            obj.name = "Obstacle";
            obj.transform.position = new Vector3(Random.Range(-530f + JuLi, -400f + JuLi), -0.01f, Random.Range(-9.5f, 9.5f));
        }
        if (ObstacleNumOne <= 100 && Player.transform.position.x >= -450f + JuLi) { ObstacleNumOne++; }
        if (ObstacleNumOne > 30 && ObstacleNumOne <= 100)
        {
            obj = GameObject.Instantiate(Obstacle);
            obj.layer = 8;
            obj.tag = "Obstacle";
            obj.name = "Obstacle";
            obj.transform.position = new Vector3(Random.Range(-400f + JuLi, -200f + JuLi), -0.01f, Random.Range(-9.5f, 9.5f));
        }
        if (ObstacleNumTwo <= 200 && Player.transform.position.x >= -250f + JuLi) { ObstacleNumTwo++; }
        if (ObstacleNumTwo > 100 && ObstacleNumTwo <= 200)
        {
            obj = GameObject.Instantiate(Obstacle);
            obj.layer = 8;
            obj.tag = "Obstacle";
            obj.name = "Obstacle";
            obj.transform.position = new Vector3(Random.Range(-200f + JuLi, 0f + JuLi), -0.01f, Random.Range(-9.5f, 9.5f));
        }
        if (ObstacleNumThree <= 300 && Player.transform.position.x >= -50f + JuLi) { ObstacleNumThree++; }
        if (ObstacleNumThree > 200 && ObstacleNumThree <= 300)
        {
            obj = GameObject.Instantiate(Obstacle);
            obj.layer = 8;
            obj.tag = "Obstacle";
            obj.name = "Obstacle";
            obj.transform.position = new Vector3(Random.Range(0f + JuLi, 200f + JuLi), -0.01f, Random.Range(-9.5f, 9.5f));
        }
        if (ObstacleNumFour <= 400 && Player.transform.position.x >= 150f + JuLi) { ObstacleNumFour++; }
        if (ObstacleNumFour > 300 && ObstacleNumFour <= 400)
        {
            obj = GameObject.Instantiate(Obstacle);
            obj.layer = 8;
            obj.tag = "Obstacle";
            obj.name = "Obstacle";
            obj.transform.position = new Vector3(Random.Range(200f + JuLi, 400f + JuLi), -0.01f, Random.Range(-9.5f, 9.5f));
        }
        if (ObstacleNumFive <= 550 && Player.transform.position.x >= 350f + JuLi) { ObstacleNumFive++; }
        if (ObstacleNumFive > 400 && ObstacleNumFive <= 550)
        {
            obj = GameObject.Instantiate(Obstacle);
            obj.layer = 8;
            obj.tag = "Obstacle";
            obj.name = "Obstacle";
            obj.transform.position = new Vector3(Random.Range(400f + JuLi, 580f + JuLi), -0.01f, Random.Range(-9.5f, 9.5f));
        }
	}
}
