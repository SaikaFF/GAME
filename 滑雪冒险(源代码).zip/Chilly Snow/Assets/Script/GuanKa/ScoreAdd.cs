﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreAdd : MonoBehaviour {
    PlayerMove Player = null;
    public static float Score;
    public static float ScoreAdddd = 0;
    float ScoreTime = 0;
	// Use this for initialization
	void Start () {
        Player = GameObject.Find("Player").GetComponent<PlayerMove>();
	}
	
	// Update is called once per frame
	void Update () {
        if (Vector3.Distance(Player.transform.position,this.transform.position) < 2.5f && Player.GG != 1 && ScoreTime == 0)
        {
            if (Player.ZhuangTai == 0)
            {
                Score = 4;
                ScoreTime = 1;
                ScoreAdddd += Score;
            }
            if (Player.ZhuangTai == 1)
            {
                Score = 8;
                ScoreTime = 1;
                ScoreAdddd += Score;
            }
        }
        if (Player.transform.position.x >= -350f + ObstacleSetting.JuLi)
        {
            if (this.transform.position.x >= -530f + ObstacleSetting.JuLi && this.transform.position.x <= -400f + ObstacleSetting.JuLi)
            {
                Destroy(gameObject);
            }
        }
        if (Player.transform.position.x >= -150f + ObstacleSetting.JuLi)
        {
            if (this.transform.position.x >= -400f + ObstacleSetting.JuLi && this.transform.position.x <= -200f + ObstacleSetting.JuLi)
            {
                Destroy(gameObject);
            }
        }
        if (Player.transform.position.x >= 50f + ObstacleSetting.JuLi)
        {
            if (this.transform.position.x >= -200f + ObstacleSetting.JuLi && this.transform.position.x <= 0f + ObstacleSetting.JuLi)
            {
                Destroy(gameObject);
            }
        }
        if (Player.transform.position.x >= 250f + ObstacleSetting.JuLi)
        {
            if (this.transform.position.x >= 0f + ObstacleSetting.JuLi && this.transform.position.x <= 200f + ObstacleSetting.JuLi)
            {
                Destroy(gameObject);
            }
        }
        if (Player.transform.position.x >= 450f + ObstacleSetting.JuLi)
        {
            if (this.transform.position.x >= 200 + ObstacleSetting.JuLi && this.transform.position.x < 400f + ObstacleSetting.JuLi)
            {
                Destroy(gameObject);
            }
        }
	}
}
