﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIMoveTwo : MonoBehaviour {
    public float Turn = 0.2f;
    PlayerMove Player;
    int Zhuang = 0;
	// Use this for initialization
	void Start () {
        Player = GameObject.Find("Player").GetComponent<PlayerMove>();
        Turn = 0.2f;
	}
	
	// Update is called once per frame
	void Update () {
        if (UIControl.WuJin == 1)
        {
            this.gameObject.SetActive(false);
        }
        if (UIControl.GuanKa == 1 || UIControl.GuanKa == 2)
        {
            this.gameObject.SetActive(true);
        }
        this.transform.Translate(new Vector3(0, 0, Turn));
        if (Zhuang != 1)
        {
            if (this.transform.position.z >= 11f)
            {
                Turn = -0.2f;
            }
            if (this.transform.position.z <= -11f)
            {
                Turn = 0.2f;
            }
        }
        if (Zhuang == 1)
        {
            Turn = 0;
        }
	}
    void OnCollisionStay(Collision other)
    {
        if (other.collider.tag == "Player")
        {
            Zhuang = 1;
            this.transform.position = new Vector3(this.transform.position.x + 1f, 0.5f, this.transform.position.z + Random.Range(-0.5f, 0.5f));
            if (Player.ZhuangTai != 1 && Player.WuDiZhuangTai != 1)
            {
                Player.life--;
                Player.MoveSpeed = 0.1f;
                Player.Turn = 0f;
                Player.KuangBao = 0f;
                Player.ZhuangTree = 1;
            }
        }
        if (other.collider.tag == "AIPlayer")
        {
            Zhuang = 1;
            this.transform.position = new Vector3(this.transform.position.x + 1f, 0.5f, this.transform.position.z + Random.Range(-0.5f, 0.5f));
        }
    }
}
