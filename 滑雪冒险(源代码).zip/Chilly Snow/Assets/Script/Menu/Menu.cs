﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour {
    public GameObject WuJinBtn;
    public GameObject GuanKaBtn;
    public GameObject QuitBtn;
    public GameObject BackBtn;
    public GameObject OneBtn;
    public GameObject TwoBtn;
    public GameObject HelpBtn;
    public GameObject HelpText;
	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
        
	}
    public void GuanKaMoShi()
    {
        OneBtn.gameObject.SetActive(true);
        TwoBtn.gameObject.SetActive(true);
        BackBtn.gameObject.SetActive(true);
        GuanKaBtn.gameObject.SetActive(false);
        WuJinBtn.gameObject.SetActive(false);
        QuitBtn.gameObject.SetActive(false);
        HelpBtn.gameObject.SetActive(false);
        HelpText.gameObject.SetActive(false);
    }
    public void WuJinMoShi()
    {
        UIControl.WuJin = 1;
        UIControl.GuanKa = 0;
        ScoreAdd.ScoreAdddd = 0;
        PlayerMove.Score = 0;
        SceneManager.LoadScene("GameSceneOne");
    }
    public void QuitGame()
    {
        #if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
        #else
                        Application.Quit();
        #endif
    }
    public void Back()
    {
        OneBtn.gameObject.SetActive(false);
        TwoBtn.gameObject.SetActive(false);
        BackBtn.gameObject.SetActive(false);
        HelpText.gameObject.SetActive(false);
        GuanKaBtn.gameObject.SetActive(true);
        WuJinBtn.gameObject.SetActive(true);
        QuitBtn.gameObject.SetActive(true);
        HelpBtn.gameObject.SetActive(true);
    }
    public void One()
    {
        UIControl.WuJin = 0;
        UIControl.GuanKa = 1;
        ScoreAdd.ScoreAdddd = 0;
        PlayerMove.Score = 0;
        SceneManager.LoadScene("GameSceneOne");
    }
    public void Two()
    {
        UIControl.WuJin = 0;
        UIControl.GuanKa = 2;
        ScoreAdd.ScoreAdddd = 0;
        PlayerMove.Score = 0;
        SceneManager.LoadScene("GameSceneOne");
    }
    public void Help()
    {
        HelpText.gameObject.SetActive(true);
        BackBtn.gameObject.SetActive(true);
        GuanKaBtn.gameObject.SetActive(false);
        WuJinBtn.gameObject.SetActive(false);
        QuitBtn.gameObject.SetActive(false);
        HelpBtn.gameObject.SetActive(false);
    }
}
