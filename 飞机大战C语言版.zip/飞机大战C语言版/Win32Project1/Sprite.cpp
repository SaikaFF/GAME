#include "Sprite.h"

//-----------------------------------------------------------------
// Sprite Constructor(s)/Destructor
//-----------------------------------------------------------------
Sprite::Sprite(Bitmap* pBitmap, RECT& rcBounds, BOUNDSACTION baBoundsAction)
{
	//����һ�����λ��
	int iXPos = rand() % (rcBounds.right - rcBounds.left);
	int iYPos = rand() % (rcBounds.bottom - rcBounds.top);
	
	// Initialize the member variables
	m_pBitmap = pBitmap;
	SetRect(&m_rcPosition, iXPos, iYPos, iXPos + pBitmap->GetWidth(),iYPos + pBitmap->GetHeight());
	CalcCollisionRect();
	m_ptVelocity.x = m_ptVelocity.y = 0;
	m_iZOrder = 0;
	CopyRect(&m_rcBounds, &rcBounds);
	m_baBoundsAction = baBoundsAction;
	m_bHidden = FALSE;

	//���Ӷ���֡��ʼ������
	m_iNumFrames = 1;
	m_iCurFrame = m_iFrameDelay = m_iFrameTrigger = 0;

	m_bDying = FALSE;
	m_bOneCycle = FALSE;
}

Sprite::Sprite(Bitmap* pBitmap, POINT ptPosition, POINT ptVelocity, int iZOrder,
			   RECT& rcBounds, BOUNDSACTION baBoundsAction)
{
	// Initialize the member variables
	m_pBitmap = pBitmap;
	SetRect(&m_rcPosition, ptPosition.x, ptPosition.y,
		ptPosition.x + pBitmap->GetWidth(), ptPosition.y + pBitmap->GetHeight());

	CalcCollisionRect();
	
	m_ptVelocity = ptVelocity;
	m_iZOrder = iZOrder;
	CopyRect(&m_rcBounds, &rcBounds);
	m_baBoundsAction = baBoundsAction;
	m_bHidden = FALSE;

	//���Ӷ���֡��ʼ������
	m_iNumFrames = 1;
	m_iCurFrame = m_iFrameDelay = m_iFrameTrigger = 0;

	m_bDying = FALSE;
	m_bOneCycle = FALSE;
}

Sprite::~Sprite()
{
}

//-----------------------------------------------------------------
// Sprite General Methods
//-----------------------------------------------------------------
SPRITEACTION Sprite::Update()//��ɾ����ƶ�����ײ���
{
	//�鿴�Ƿ���Ҫɾ������
	if(m_bDying)
		return SA_KILL;

	//����֡
	UpdateFrame();

	//����λ��
	POINT ptNewPosition, ptSpriteSize, ptBoundsSize;
	ptNewPosition.x = m_rcPosition.left + m_ptVelocity.x;
	ptNewPosition.y = m_rcPosition.top + m_ptVelocity.y;
	ptSpriteSize.x = m_rcPosition.right - m_rcPosition.left;
	ptSpriteSize.y = m_rcPosition.bottom - m_rcPosition.top;
	ptBoundsSize.x = m_rcBounds.right - m_rcBounds.left;
	ptBoundsSize.y = m_rcBounds.bottom - m_rcBounds.top;
	
	// ���߽綯��
	// ����?
	if (m_baBoundsAction == BA_WRAP)
	{
		if ((ptNewPosition.x + ptSpriteSize.x) < m_rcBounds.left)
			ptNewPosition.x = m_rcBounds.right;//������ߣ����ƶ����ұ߽߱�
		else if (ptNewPosition.x > m_rcBounds.right)
			ptNewPosition.x = m_rcBounds.left - ptSpriteSize.x;
		if ((ptNewPosition.y + ptSpriteSize.y) < m_rcBounds.top)
			ptNewPosition.y = m_rcBounds.bottom;
		else if (ptNewPosition.y > m_rcBounds.bottom)
			ptNewPosition.y = m_rcBounds.top - ptSpriteSize.y;
	}
	// ����?�������ٶȷ���
	else if (m_baBoundsAction == BA_BOUNCE)
	{
		BOOL bBounce = FALSE;
		POINT ptNewVelocity = m_ptVelocity;
		if (ptNewPosition.x < m_rcBounds.left)
		{
			bBounce = TRUE;
			ptNewPosition.x = m_rcBounds.left;
			ptNewVelocity.x = -ptNewVelocity.x;
		}
		else if ((ptNewPosition.x + ptSpriteSize.x) > m_rcBounds.right)
		{
			bBounce = TRUE;
			ptNewPosition.x = m_rcBounds.right - ptSpriteSize.x;
			ptNewVelocity.x = -ptNewVelocity.x;
		}
		if (ptNewPosition.y < m_rcBounds.top)
		{
			bBounce = TRUE;
			ptNewPosition.y = m_rcBounds.top;
			ptNewVelocity.y = -ptNewVelocity.y;
		}
		else if ((ptNewPosition.y + ptSpriteSize.y) > m_rcBounds.bottom)
		{
			bBounce = TRUE;
			ptNewPosition.y = m_rcBounds.bottom - ptSpriteSize.y;
			ptNewVelocity.y = -ptNewVelocity.y;
		}
		if (bBounce)//�����ٶ�
			SetVelocity(ptNewVelocity);
	}

	// Die?
	else if (m_baBoundsAction == BA_DIE)
	{
		if ((ptNewPosition.x + ptSpriteSize.x) < m_rcBounds.left ||
			ptNewPosition.x > m_rcBounds.right ||
			(ptNewPosition.y + ptSpriteSize.y) < m_rcBounds.top ||
			ptNewPosition.y > m_rcBounds.bottom)
			return SA_KILL;
	}
	
	//ֹͣ(Ĭ��)
	else
	{
		//�ı��ٶȣ���ֹͣ����
		if (ptNewPosition.x  < m_rcBounds.left ||
			ptNewPosition.x > (m_rcBounds.right - ptSpriteSize.x))
		{
			ptNewPosition.x = max(m_rcBounds.left, min(ptNewPosition.x,
				m_rcBounds.right - ptSpriteSize.x));
			SetVelocity(0, 0);
		}
		if (ptNewPosition.y  < m_rcBounds.top ||
			ptNewPosition.y > (m_rcBounds.bottom - ptSpriteSize.y))
		{
			ptNewPosition.y = max(m_rcBounds.top, min(ptNewPosition.y,
				m_rcBounds.bottom - ptSpriteSize.y));
			SetVelocity(0, 0);
		}
	}
	SetPosition(ptNewPosition);

	return SA_NONE;
}

void Sprite::Draw(HDC hDC,bool bTrans, COLORREF crTransColor)
{
	// Draw the sprite if it isn't hidden
	if (m_pBitmap != NULL && !m_bHidden)
	{
		if(m_iNumFrames == 1)
		{
			if(!bTrans)
				m_pBitmap->Draw(hDC, m_rcPosition.left, m_rcPosition.top);
			else
				m_pBitmap->Draw(hDC, m_rcPosition.left, m_rcPosition.top, true, crTransColor);
		}
		else
		{
			m_pBitmap->DrawPart(hDC, m_rcPosition.left, m_rcPosition.top, 
			0, m_iCurFrame*GetHeight(), GetWidth(), GetHeight(), true, crTransColor);
		}
	}
}

Sprite* Sprite::AddSprite()
{
	return NULL;
}

void Sprite::UpdateFrame()//��Update��������
{
	if ((m_iFrameDelay >= 0) && (--m_iFrameTrigger <= 0))
	{
		//����֡������
		m_iFrameTrigger = m_iFrameDelay;

		//֡������1
		//�޸ģ����ֻ�ǲ���һ��֡ѭ����������m_bDyingΪtrue���������¿�ʼ����
		if (++m_iCurFrame >= m_iNumFrames)
		{
			if(m_bOneCycle)
				m_bDying = true;
			else
				m_iCurFrame = 0;
		}
	}
}

void Sprite::CalcCollisionRect()
{
	//ȱʡʵ��Ϊ����ײ���α�λ�þ���С1/6
	int iXShrink = (m_rcPosition.left - m_rcPosition.right) / 12;
	int iYShrink = (m_rcPosition.top - m_rcPosition.bottom) / 12;
	CopyRect(&m_rcCollision, &m_rcPosition);
	InflateRect(&m_rcCollision, iXShrink, iYShrink);
}

BOOL Sprite::TestCollision(Sprite* pTestSprite)
{
	//���������ײ�����Ƿ����ص�
	RECT& rcTest = pTestSprite->GetCollision();
	return m_rcCollision.left <= rcTest.right && rcTest.left <= m_rcCollision.right &&
		m_rcCollision.top <= rcTest.bottom && rcTest.top <= m_rcCollision.bottom;
}

BOOL Sprite::IsPointInside(int x, int y)
{
	POINT ptPoint;
	ptPoint.x = x;
	ptPoint.y = y;
	return PtInRect(&m_rcPosition, ptPoint);
}

//���Ӿ��鶯��֧��
/*
ע�⣺��Ϊͼ�����ڰ����˶��֡������ʹ��������ͼ���С�����Ա������¼��㾫���λ��
*/
void Sprite::SetNumFrames(int iNumFrames, BOOL bOneCycle)
{
	//����֡��
	m_iNumFrames = iNumFrames;

	//���¼���λ��
	RECT rect = GetPosition();
	rect.bottom = rect.top + ((rect.bottom - rect.top) / iNumFrames);
	SetPosition(rect);

	m_bOneCycle = bOneCycle;
}

void Sprite::SetPosition(int x, int y)
{
	OffsetRect(&m_rcPosition, x - m_rcPosition.left, y - m_rcPosition.top);
	CalcCollisionRect();
}

void Sprite::SetPosition(POINT ptPosition)
{
	OffsetRect(&m_rcPosition, ptPosition.x - m_rcPosition.left,
		ptPosition.y - m_rcPosition.top);
	CalcCollisionRect();
}

void Sprite::OffsetPosition(int x, int y)
{
	OffsetRect(&m_rcPosition, x, y);
	CalcCollisionRect();
}

void Sprite::SetVelocity(int x, int y)
{
	m_ptVelocity.x = x;
	m_ptVelocity.y = y;
}

void Sprite::SetVelocity(POINT ptVelocity)
{
	m_ptVelocity.x = ptVelocity.x;
	m_ptVelocity.y = ptVelocity.y;
}