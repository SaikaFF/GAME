#pragma once

#include "Sprite.h"

class BossSprite : public Sprite
{
public:
	BossSprite(Bitmap* pBitmap, RECT& rcBounds, BOUNDSACTION baBoundsAction = BA_STOP);
	virtual ~BossSprite();

	virtual SPRITEACTION Update();
	virtual Sprite* AddSprite();
};