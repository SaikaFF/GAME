#pragma once

#include "Sprite.h"

class PlaneSprite : public Sprite
{
	public:
	 PlaneSprite(Bitmap* pBitmap, RECT& rcBounds, BOUNDSACTION baBoundsAction = BA_STOP);
	virtual ~ PlaneSprite();

	virtual SPRITEACTION Update();
	virtual Sprite* AddSprite();
};