#define WIN32_LEAN_AND_MEAN 

#include <windows.h>
#include <windowsx.h> 
#include <mmsystem.h> 
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "GameEngine.h"
#include "AlienSprite.h"
#include "Plane.h"
#include "BOSS.h"

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "msimg32.lib")
//////////////////////////////////////////////////////////////////////

#define WINDOW_CLASS_NAME "WINCLASS1"

const int WINDOW_WIDTH = 640;
const int WINDOW_HEIGHT = 480;

// GLOBALS ////////////////////////////////////////////////

HWND      g_hWnd = NULL;
HINSTANCE g_hInstance = NULL;

HDC         g_hOffscreenDC;
HBITMAP     g_hOffscreenBitmap;

Bitmap*           g_pBackgroundBitmap;  //����

Bitmap*           g_pShipBitmap;//�ִ�λͼ
Bitmap*           g_pBombBitmap;//����λͼ

Bitmap*           g_pLeftSubmarineBitmap;//Ǳͧλͼ
Bitmap*           g_pRightSubmarineBitmap;//Ǳͧλͼ
Bitmap*           g_pTorpedoBitmap;//ˮ��λͼ

Bitmap*           g_pLplaneBitmap;//�ɻ�λͼ
Bitmap*           g_pRplaneBitmap;//�ɻ�λͼ
Bitmap*           g_pPlaneFireBitmap;//�ɻ�����λͼ

Bitmap*           g_pBOSSBitmap;//BOSSλͼ
Bitmap*           g_pBOSSFireBitmap;//BOSS����λͼ

Bitmap*           g_pBigFireBitmap;//�����Ѷ�λͼ
Bitmap*           g_pseaBitmap;//����λͼ

Bitmap*           g_pWinBitmap;//ʤ��λͼ

Bitmap*           g_pGameOverBitmap;
Bitmap*           g_pSmExplosionBitmap;
Bitmap*           g_pLgExplosionBitmap;

Sprite*           g_pShipSprite;
//�����ӳ�

int               g_iFireInputDelay;
int               g_iNumLives, g_iScore, g_iDifficulty;
int               g_shengming;
int               g_bignum;
int               g_shipnum;
BOOL              g_bGameOver;
BOOL              g_bWin;
int time=0;
int time1=0;

// FUNCTIONS //////////////////////////////////////////////

//������ײ�¼���Ӧ����
BOOL SpriteCollision(Sprite* pSpriteHitter, Sprite* pSpriteHittee)
{
	//�鿴��ҵ���������Ǳͧ�������ײ
	Bitmap* pHitter = pSpriteHitter->GetBitmap();
	Bitmap* pHittee = pSpriteHittee->GetBitmap();

	if ((pHitter == g_pBombBitmap && (pHittee == g_pLeftSubmarineBitmap ||	pHittee == g_pRightSubmarineBitmap)) ||
		(pHittee == g_pBombBitmap && (pHitter == g_pLeftSubmarineBitmap ||    pHitter == g_pRightSubmarineBitmap ))||
		(pHitter == g_pPlaneFireBitmap && (pHittee == g_pLeftSubmarineBitmap ||	pHittee == g_pRightSubmarineBitmap))||
		(pHittee == g_pPlaneFireBitmap && (pHitter == g_pLeftSubmarineBitmap ||    pHitter == g_pRightSubmarineBitmap )))
	{
		//ɾ������
		pSpriteHitter->Kill();
		pSpriteHittee->Kill();
		
		//��Ǳͧ��λ�ô���һ����ը����
		RECT rcBounds = { 0, 0, 640, 480 };
		RECT rcPos;
		if (pHitter == g_pBombBitmap||pHitter == g_pPlaneFireBitmap)
			rcPos = pSpriteHittee->GetPosition();
		else
			rcPos = pSpriteHitter->GetPosition();
		Sprite* pSprite = new Sprite(g_pLgExplosionBitmap, rcBounds);
		pSprite->SetNumFrames(8, TRUE);//��ը����ֻ����һ��
		pSprite->SetPosition(rcPos.left, rcPos.top);
		AddSprite(pSprite);
		
		//���µ÷�
		g_shipnum++;
		g_iScore += 10;
		g_iDifficulty = max(80 - (g_iScore / 20), 20);
	}

	//ը����BOSS����ײ

	if(pHitter == g_pBombBitmap && (pHittee == g_pBOSSBitmap)||pHittee == g_pBombBitmap && (pHitter == g_pBOSSBitmap)||
		(pHitter == g_pPlaneFireBitmap && (pHittee == g_pBOSSBitmap ||	pHittee == g_pBOSSBitmap)))
	{
		g_shengming=g_shengming-1;
		if(g_shengming<=0)
		{
			g_iScore += 1000;
			g_bWin = TRUE;
		}

		if (pHitter == g_pBOSSBitmap)
			pSpriteHittee->Kill();
		else
			pSpriteHitter->Kill();

		RECT rcBounds = { 0, 0, 640, 480 };
			RECT rcPos;
			if (pHitter == g_pBombBitmap||pHitter == g_pPlaneFireBitmap)
				rcPos = pSpriteHittee->GetPosition();
			else
				rcPos = pSpriteHitter->GetPosition();
			Sprite* pSprite = new Sprite(g_pLgExplosionBitmap, rcBounds);
			pSprite->SetNumFrames(8, TRUE);//��ը����ֻ����һ��
			pSprite->SetPosition(rcPos.left, rcPos.top);
			AddSprite(pSprite);
			g_iScore += 2;
	}

	//�ӵ�֮�����ײ

	if((pHitter == g_pPlaneFireBitmap && (pHittee == g_pTorpedoBitmap ||	pHittee == g_pTorpedoBitmap))||
		(pHitter == g_pBombBitmap && (pHittee == g_pTorpedoBitmap ||	pHittee == g_pTorpedoBitmap)))
		{
			//ɾ������
		pSpriteHitter->Kill();
		pSpriteHittee->Kill();
		
		//��Ǳͧ��λ�ô���һ����ը����
		RECT rcBounds = { 0, 0, 640, 480 };
		RECT rcPos;
		if (pHitter == g_pBombBitmap||pHitter == g_pPlaneFireBitmap)
			rcPos = pSpriteHittee->GetPosition();
		else
			rcPos = pSpriteHitter->GetPosition();
		Sprite* pSprite = new Sprite(g_pLgExplosionBitmap, rcBounds);
		pSprite->SetNumFrames(8, TRUE);//��ը����ֻ����һ��
		pSprite->SetPosition(rcPos.left, rcPos.top);
		AddSprite(pSprite);
		}
	
	//�鿴ˮ�׺�BOSS����������ִ�����ײ
	if ((pHitter == g_pShipBitmap && pHittee == g_pTorpedoBitmap ) ||
		(pHittee == g_pShipBitmap && pHitter == g_pTorpedoBitmap)||
		(pHitter == g_pShipBitmap && pHittee == g_pBOSSFireBitmap )||
		(pHittee == g_pShipBitmap && pHitter == g_pBOSSFireBitmap ))

	{		
		//��ɾ��ˮ�׾���
		if (pHitter == g_pShipBitmap)
			pSpriteHittee->Kill();
		else
			pSpriteHitter->Kill();
		
		//���ִ���λ�ô���һ����ը����
		RECT rcBounds = { 0, 0, 640, 480 };
		RECT rcPos;
		if (pHitter == g_pShipBitmap)
			rcPos = pSpriteHitter->GetPosition();
		else
			rcPos = pSpriteHittee->GetPosition();
		Sprite* pSprite = new Sprite(g_pLgExplosionBitmap, rcBounds);
		pSprite->SetNumFrames(8, TRUE);
		pSprite->SetPosition(rcPos.left, rcPos.top);
		AddSprite(pSprite);
		
		g_pShipSprite->SetPosition(320, 400);


		// See if the game is over
		if (--g_iNumLives == 0)
		{
			g_bGameOver = TRUE;
		}
	}
	
	return FALSE;
}

//���ƻ�����ʱ����Ӧ����
void SpriteDying(Sprite* pSpriteDying)
{
	//�鿴�Ƿ�����ɾ������Ǳͧ��ˮ�׾���
	if (pSpriteDying->GetBitmap() == g_pTorpedoBitmap)
	{
		//��ˮ�׵�λ�ô���һ����С�ı�ը����
		RECT rcBounds = { 0, 70, 640, 480 };
		RECT rcPos = pSpriteDying->GetPosition();
		Sprite* pSprite = new Sprite(g_pSmExplosionBitmap, rcBounds);
		pSprite->SetNumFrames(8, TRUE);
		pSprite->SetPosition(rcPos.left, rcPos.bottom);
		AddSprite(pSprite);
	}
}

/////////////////////////////////////////////////////////////////////////////

void NewGame()
{
	// Clear the sprites
    CleanupSprites();
	
	// Create the car sprite
	RECT rcBounds = { 0, 0, 640, 480 };
	g_pShipSprite = new Sprite(g_pShipBitmap, rcBounds, BA_WRAP);
	g_pShipSprite->SetPosition(320,400);
	AddSprite(g_pShipSprite);
	
	// Initialize the game variables
	g_iFireInputDelay = 0;
	g_iScore = 0;
	g_iNumLives = 10;
	g_shengming=666; 
	g_iDifficulty = 80;
	g_bignum=3;
	g_shipnum=0;
	g_bGameOver = FALSE;
	g_bWin = FALSE;
	
	// Play the background music
	PlayMIDISong();
}

void AddPlane()//���ӷɻ�
{
	RECT          rcBounds = { 0, 0, 640, 480 };
	PlaneSprite*  pSpritep;
	switch(rand() % 2)
	{
	case 0:
		// left
		pSpritep = new PlaneSprite(g_pLplaneBitmap, rcBounds, BA_WRAP);
		pSpritep->SetPosition(640, 350);
		//�ٶȷ�Χ-2~4
		pSpritep->SetVelocity(-(rand() % 4) , 0);
		break;
	case 1:
		// right
		pSpritep = new PlaneSprite(g_pRplaneBitmap, rcBounds, BA_WRAP);
		pSpritep->SetPosition(-64, 350);
		pSpritep->SetVelocity((rand() % 4) , 0);
		break;
	}

	// Add the plane spritep
	AddSprite(pSpritep);
}

void AddSubmarine()//����Ǳˮͧ
{
	// Create a new random alien sprite
	RECT          rcBounds = { 0, 0, 640, 480 };
	AlienSprite*  pSprite;
	switch(rand() % 2)
	{
	case 0:
		// left
		pSprite = new AlienSprite(g_pLeftSubmarineBitmap, rcBounds, BA_WRAP);
		pSprite->SetPosition(640, 40-27);
		//�ٶȷ�Χ-2~4
		pSprite->SetVelocity(-(rand() % 4) , 1);
		break;
	case 1:
		// right
		pSprite = new AlienSprite(g_pRightSubmarineBitmap, rcBounds, BA_WRAP);
		pSprite->SetPosition(-64, 40-27);
		pSprite->SetVelocity((rand() % 4) , 2);
		break;
	}

	// Add the alien sprite
	AddSprite(pSprite);
}

void AddBOSS()//����BOSS
{
	// Create a new random alien sprite
	RECT          rcBounds = { 0, 0, 640, 480 };
	BossSprite*  pSprite;
	/*switch(rand() % 2)
	{
	case 0:*/
		// left
		pSprite = new BossSprite(g_pBOSSBitmap, rcBounds, BA_WRAP);
		pSprite->SetPosition(640,40-30);
		//�ٶȷ�Χ-2~4
		pSprite->SetVelocity(-(rand() % 4) , 0);
		/*break;*/
	//case 1:
	//	// right
	//	pSprite = new BossSprite(g_pRightSubmarineBitmap, rcBounds, BA_WRAP);
	//	pSprite->SetPosition(-64, rand()%300+100);
	//	pSprite->SetVelocity((rand() % 4) , 0);
	//	break;
	/*}*/

	// Add the alien sprite
	AddSprite(pSprite);
}

//////////////////////////////////////////////////////////////

void GameStart(HDC hDC)
{
	//�����������������
	srand(GetTickCount());
	
	//������Ļ���豸������λͼ
	g_hOffscreenDC = CreateCompatibleDC(hDC);
	g_hOffscreenBitmap = CreateCompatibleBitmap(hDC,WINDOW_WIDTH, WINDOW_HEIGHT);
	SelectObject(g_hOffscreenDC, g_hOffscreenBitmap);
	
	g_pBackgroundBitmap= new Bitmap(hDC, "Res/background.bmp");
	g_pseaBitmap= new Bitmap(hDC, "Res/sea.bmp");
	g_pShipBitmap= new Bitmap(hDC, "Res/SHIP.BMP");
	g_pLeftSubmarineBitmap= new Bitmap(hDC, "Res/submarine1.bmp");
	g_pRightSubmarineBitmap= new Bitmap(hDC, "Res/submarine2.bmp");
	g_pBombBitmap= new Bitmap(hDC, "Res/BOMB.BMP");
	g_pTorpedoBitmap= new Bitmap(hDC, "Res/TORPEDO.bmp");
	g_pSmExplosionBitmap = new Bitmap(hDC, "Res/SmExplosion.bmp");
	g_pLgExplosionBitmap = new Bitmap(hDC, "Res/LgExplosion.bmp");
	g_pGameOverBitmap = new Bitmap(hDC, "Res/GameOver.bmp");
	g_pLplaneBitmap = new Bitmap(hDC,"Res/planeL.bmp");
	g_pRplaneBitmap = new Bitmap(hDC,"Res/planeR.bmp");
	g_pPlaneFireBitmap = new Bitmap(hDC,"Res/FirePlane.bmp");
	g_pBOSSBitmap = new Bitmap(hDC,"Res/BOSS.bmp");
	g_pBOSSFireBitmap = new Bitmap(hDC,"Res/BOSSFire.bmp");
	g_pWinBitmap = new Bitmap(hDC,"Res/Win.bmp");
	g_pBigFireBitmap = new Bitmap(hDC,"Res/BigFire.bmp");
	
	// Start the game
	NewGame();
}

//void GameMenu(HDC hDC)
//{
//	g_pseaBitmap->Draw(hDC,0,0);
//	if (KEYDOWN(VK_SPACE))
//		NewGame();
//}

void GameEnd()
{
	CloseMIDIPlayer();
	
	// Cleanup the offscreen device context and bitmap
	DeleteObject(g_hOffscreenBitmap);
	DeleteDC(g_hOffscreenDC);  
	
	// Cleanup the bitmaps
	delete g_pBackgroundBitmap ;
	delete g_pShipBitmap;
	delete g_pLeftSubmarineBitmap;
	delete g_pRightSubmarineBitmap;
	delete g_pBombBitmap;
	delete g_pTorpedoBitmap;
	delete g_pSmExplosionBitmap;
	delete g_pLgExplosionBitmap;
	delete g_pLplaneBitmap;
	delete g_pRplaneBitmap;
	delete g_pPlaneFireBitmap;
	delete g_pGameOverBitmap;
	delete g_pBOSSBitmap;
	delete g_pBOSSFireBitmap;
	delete g_pWinBitmap;
	delete g_pBigFireBitmap;
	
	time=0;
	// Cleanup the sprites
	CleanupSprites();
	
}

void GamePaint(HDC hDC)
{
	//���Ʊ���
	g_pBackgroundBitmap->Draw(hDC,0,0);
	
	//���ƾ���
	DrawSprites(hDC);
	
	//���Ƶ÷�
	TCHAR szText[64];
	TCHAR BOSSMINGText[64];
	TCHAR SHIPMINGText[64];
	TCHAR BIGFIREText[500];
	TCHAR SHIPNUMText[64];
	TCHAR TIPText[300];
	TCHAR TIP2Text[300];
	RECT  rect = { 270, 0, 370, 30 };
	RECT  BOSSMINGrect = { -200, 0, 370, 30 };
	RECT  SHIPMINGrect = { 700, 0, 370, 30 };
	RECT  BIGFIRErect = { -65, 0, 370, 80 };
	RECT  SHIPNUMrect = { 700, 0, 370, 100 };
	RECT  TIPrect = { -50, 0, 370, 850 };
	RECT  TIP2rect = { -150, 0, 370, 120 };
	wsprintf(SHIPMINGText, "��ҵ�ǰ����ֵ��%d",g_iNumLives);
	wsprintf(BOSSMINGText, "BOSS��ǰ����ֵ��%d",g_shengming);
	wsprintf(BIGFIREText, "��K�������Ѷȣ�ÿ�μ�2000�֣���BOSS30Ѫ");
	wsprintf(SHIPNUMText, "����������%d",g_shipnum);
	wsprintf(TIPText, "BOSSѪ������100��ʱ���޷������Ѷȣ�");
	wsprintf(TIP2Text, "����ֵ+3,ʣ�ࣺ%d ��",g_bignum);
	wsprintf(szText, "%d", g_iScore);
	SetBkMode(hDC, TRANSPARENT);
	SetTextColor(hDC, RGB(255, 255, 255));
	DrawText(hDC, szText, -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	DrawText(hDC, BOSSMINGText, -1, &BOSSMINGrect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	DrawText(hDC, SHIPMINGText, -1, &SHIPMINGrect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	DrawText(hDC, BIGFIREText, -1, &BIGFIRErect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	DrawText(hDC, SHIPNUMText, -1, &SHIPNUMrect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	DrawText(hDC, TIPText, -1, &TIPrect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	DrawText(hDC, TIP2Text, -1, &TIP2rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	//���б�Ҫ��������Ϸ������Ϣ
	if (g_bGameOver)
		g_pGameOverBitmap->Draw(hDC, 190, 140, TRUE, RGB(255,0,255));
	if (g_bWin)
	{
		g_pWinBitmap->Draw(hDC,30, 0, true, RGB(255, 0, 255));
	}
}

void GameCycle(HDC hDC)
{
	if (!g_bGameOver&&!g_bWin)
	{
		if ((rand() % g_iDifficulty) == 0)
		{
			AddSubmarine();
			AddSubmarine();
		}
		if (time1==0)
		{
			AddBOSS();
			time1++;
		}
		if (time<5)
		{
			AddPlane();
			time++;
		}
		//���¾���
		UpdateSprites();
		
		GamePaint(g_hOffscreenDC);
		
		// Blit the offscreen bitmap to the game screen
		BitBlt(hDC, 0, 0, WINDOW_WIDTH,WINDOW_HEIGHT, g_hOffscreenDC, 0, 0, SRCCOPY);
	}
}

void HandleKeys()
{
	if (!g_bGameOver&&!g_bWin)
	{
		// Move the car based upon left/right key presses
		POINT ptVelocity = g_pShipSprite->GetVelocity();
		//�˴�������ʻ���ٶȴ��������ٶȣ��Ӷ��ܺõ�ģ���˵����ٶ�С��ǰ���ٶȵ���ʵ���
		if ( KEYDOWN(VK_LEFT) )
		{
			//�����ƶ�
			ptVelocity.x = max(ptVelocity.x - 1, -4);
			g_pShipSprite->SetVelocity(ptVelocity);
		}
		else if ( KEYDOWN(VK_RIGHT) )
		{
			//�����ƶ�
			ptVelocity.x = min(ptVelocity.x + 2, 6);
			g_pShipSprite->SetVelocity(ptVelocity);
		}
		
		//���¿ո��ʱ���䵼��
		if ((++g_iFireInputDelay > 6) && KEYDOWN(VK_SPACE) )
		{
			// Create a new missile sprite
			RECT  rcBounds = { 0, 0, 640, 480 };
			RECT  rcPos = g_pShipSprite->GetPosition();
			Sprite* pSprite = new Sprite(g_pBombBitmap, rcBounds, BA_DIE);
			pSprite->SetPosition(rcPos.left + 15, 400);
			pSprite->SetVelocity(0, -3);
			AddSprite(pSprite);
						
			// ���������ӳ�
			g_iFireInputDelay = 0;
		}
	}

	if (g_shengming<=100) g_bignum=0;

	if ((++g_iFireInputDelay > 6) && KEYDOWN(75) && g_bignum>0 && g_shengming>100) //���� K��
	{
		g_shengming=g_shengming-30;
		g_iScore=g_iScore+2000;
		g_bignum--;
		g_iFireInputDelay = 0;
		g_iNumLives=g_iNumLives+3;
	}
	
	//���»س���ʱ��ʼһ������Ϸ
	/*if (g_bGameOver && KEYDOWN(VK_RETURN) || g_bWin && KEYDOWN(VK_RETURN))
		NewGame();*/
}

/////////////////////////////////////////////////////////////////////

LRESULT CALLBACK WindowProc(HWND hwnd,UINT msg,WPARAM wparam,LPARAM lparam)
{
	switch(msg)
	{
	case WM_DESTROY: 
		PostQuitMessage(0);
		break;		
	default:
		break;		
    }	
	return (DefWindowProc(hwnd, msg, wparam, lparam));
}

int WINAPI WinMain(	HINSTANCE hinstance,
				   HINSTANCE hprevinstance,
				   LPSTR lpcmdline,
				   int ncmdshow)
{
	WNDCLASSEX winclass;	
	winclass.cbSize         = sizeof(WNDCLASSEX);
	winclass.style			= CS_DBLCLKS | CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	winclass.lpfnWndProc	= WindowProc;
	winclass.cbClsExtra		= 0;
	winclass.cbWndExtra		= 0;
	winclass.hInstance		= hinstance;
	winclass.hIcon			= LoadIcon(hinstance, IDI_APPLICATION);
	winclass.hCursor		= LoadCursor(NULL, IDC_ARROW); 
	winclass.hbrBackground	= (HBRUSH)GetStockObject(BLACK_BRUSH);
	winclass.lpszMenuName	= NULL;
	winclass.lpszClassName	= WINDOW_CLASS_NAME;
	winclass.hIconSm        = LoadIcon(hinstance, IDI_APPLICATION);
	
	g_hInstance = hinstance;
	
	if (!RegisterClassEx(&winclass))
		return(0);
	
	HWND	   hwnd;	
	if (!(hwnd = CreateWindowEx(NULL,                // extended style
		WINDOW_CLASS_NAME,   // class
		"Submarine", // title
		WS_OVERLAPPEDWINDOW | WS_VISIBLE,
		0,0,	  // initial x,y
		WINDOW_WIDTH, // initial width
		WINDOW_HEIGHT,// initial height
		NULL,	  // handle to parent 
		NULL,	  // handle to menu
		hinstance,// instance of this application
		NULL)))	// extra creation parms
		return(0);
	
	g_hWnd = hwnd;
	
	HDC hdc = GetDC(hwnd);
	
	GameStart(hdc);

	MSG msg;
	while(TRUE)
	{
		DWORD start = GetTickCount();
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))
		{ 
			if (msg.message == WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		} 
	
		HandleKeys();        
		GameCycle(hdc);
			
		if(GetTickCount()-start < 33)
			Sleep(33-(GetTickCount()-start));		
	}	

	GameEnd();

	ReleaseDC(hwnd, hdc);
	
	return(msg.wParam);
}

