#include "Plane.h"

extern Bitmap* g_pPlaneFireBitmap;
extern Bitmap* g_pRplaneBitmap;
extern Bitmap* g_pLplaneBitmap;

extern int     g_iDifficulty;

 PlaneSprite:: PlaneSprite(Bitmap* pBitmap, RECT& rcBounds, BOUNDSACTION baBoundsAction) 
			: Sprite(pBitmap, rcBounds, baBoundsAction)
{
}

 PlaneSprite::~PlaneSprite()
{
}

  Sprite* PlaneSprite::AddSprite()
{
	RECT  rcBounds = { 0, 0, 640, 480 };
	RECT rcPos = GetPosition();

	Sprite* pSprite = NULL;
	
	pSprite = new Sprite(g_pPlaneFireBitmap, rcBounds, BA_DIE);
	pSprite->SetVelocity(0, -3);	

	int xpos = rcPos.left + GetWidth()/2;
	if(xpos <=0 || xpos>=640)
		return NULL;
	pSprite->SetPosition(xpos, rcPos.top);

	return pSprite;
}

  SPRITEACTION PlaneSprite::Update()
{	
	//���û����Update()����
	SPRITEACTION saSpriteAction;
	saSpriteAction = Sprite::Update();

	//�鿴�ɻ��Ƿ�Ӧ�÷��䵼��(ͨ���Ѷȼ�����Ʒɻ����䵼�����ٶ�)
	if( (rand() % (g_iDifficulty) ) == 0)
		saSpriteAction |= SA_ADDSPRITE;

	return saSpriteAction;
}