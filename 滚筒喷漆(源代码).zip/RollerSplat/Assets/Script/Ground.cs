﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ground : MonoBehaviour {
    PlayerMove Player = null;
    public static Vector3 Last;
    public float win;
    public static float WinNum;
    float TTime;
	// Use this for initialization
	void Start () {
        Player = GameObject.Find("Player").GetComponent<PlayerMove>();
        win = 0;
        WinNum = 0;
	}
	
	// Update is called once per frame
	void Update () {

	}
    void OnCollisionEnter(Collision other)
    {
        if (other.collider.tag == "Player")
        {
            Last = this.transform.position;
            this.GetComponent<MeshRenderer>().material.color = new Color(47f/255f, 172f/255f, 0);
            if (win < 1)
            {
                win = 1;
                WinNum++;
            }
        }
    }
}
