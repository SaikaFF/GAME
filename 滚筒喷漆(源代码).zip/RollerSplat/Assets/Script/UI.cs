﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class UI : MonoBehaviour {
    public static float GuanKa = 1;
    public GameObject WinTxt;
    public GameObject TryAgainBtn;
    public GameObject QuitBtn;
    public GameObject CameraPositon;
    public GameObject BackBtn;
    public GameObject LevelUp;
    PlayerMove Player = null;
    int LevelUpTxtTime;
    int LevelWin;
    float i = 0;
    public static float winwin = 0;
	// Use this for initialization
	void Start () {
        GuanKa = 1;
        winwin = 0;
        Player = GameObject.Find("Player").GetComponent<PlayerMove>();
        LevelWin = 0;
	}
	
	// Update is called once per frame
	void Update () {
        if (GuanKa == 1 && Ground.WinNum == 58)
        {
            Player.transform.position = new Vector3(17.157f, -0.55f, -5.043f);
            CameraPositon.transform.position = new Vector3(18.81f, 10.51937f, -4.39f);
            Ground.WinNum = 0;
            GuanKa = 2;
            Player.transform.position = new Vector3(17.157f, -0.55f, -5.043f);
            Player.XMoveSpeed = 0;
            Player.ZMoveSpeed = 0;
            LevelWin = 1;
            i = 0;
        }
        if (GuanKa == 2 && Ground.WinNum == 61)
        {
            Player.transform.position = new Vector3(5.693f, -0.55f, -21.28f);
            CameraPositon.transform.position = new Vector3(4.2f, 10.51937f, -20f);
            Ground.WinNum = 0;
            GuanKa = 3;
            Player.transform.position = new Vector3(5.693f, -0.55f, -21.28f);
            Player.XMoveSpeed = 0;
            Player.ZMoveSpeed = 0;
            LevelWin = 1;
            i = 0;
        }
        if (GuanKa == 3 && Ground.WinNum == 67)
        {
            Player.transform.position = new Vector3(17.77f, -0.55f, -14.72f);
            CameraPositon.transform.position = new Vector3(20.1f, 10.51937f, -20f);
            Ground.WinNum = 0;
            GuanKa = 4;
            Player.transform.position = new Vector3(17.77f, -0.55f, -14.72f);
            Player.XMoveSpeed = 0;
            Player.ZMoveSpeed = 0;
            LevelWin = 1;
            i = 0;
        }
        if (GuanKa == 4 && Ground.WinNum == 60)
        {
            Player.XMoveSpeed = 0;
            Player.ZMoveSpeed = 0;
            WinTxt.gameObject.SetActive(true);
            winwin = 1;
            QuitBtn.gameObject.SetActive(true);
            WinTxt.gameObject.SetActive(true);
            TryAgainBtn.gameObject.SetActive(true);
            BackBtn.gameObject.SetActive(true);
            LevelWin = 1;
            i = 0;
        }
        if (LevelWin == 1)
        {
            LevelUp.gameObject.SetActive(true);
            i++;
            if (i <= 60f)
            {
                LevelUp.GetComponent<RectTransform>().localScale = new Vector3(i / 60f * 5f, i / 60f * 2, 0);
            }
            if (i > 60f && i < 120f)
            {
                LevelUp.GetComponent<RectTransform>().localScale = new Vector3(60f / i * 5f, 60f / i * 2, 0);
            }
            if (i >= 120f)
            {
                LevelUp.gameObject.SetActive(false);
            }
        }
	}
    public void QuitGame()
    {
        #if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
        #else
                                Application.Quit();
        #endif
    }
    public void TryAgain()
    {
        //Player.transform.position = new Vector3(3.1594f, 0, -1.2558f);
        //CameraPositon.transform.position = new Vector3(3.53f, 10.51937f, -4.39f);
        //Ground.WinNum = 0;
        //GuanKa = 1;
        //Player.transform.position = new Vector3(3.1594f, 0, -1.2558f);
        //Player.XMoveSpeed = 0;
        //Player.ZMoveSpeed = 0;
        //QuitBtn.gameObject.SetActive(false);
        //WinTxt.gameObject.SetActive(false);
        //TryAgainBtn.gameObject.SetActive(false);
        SceneManager.LoadScene("GameScene");
    }
    public void Back()
    {
        SceneManager.LoadScene("Menu");
    }
}
