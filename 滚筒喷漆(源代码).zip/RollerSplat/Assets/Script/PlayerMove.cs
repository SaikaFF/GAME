﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PlayerMove : MonoBehaviour
{
    public float XMoveSpeed;
    public float ZMoveSpeed;
    int zhaung = 0;
    Vector3 lastPoint;
    float xx;
    float yy;
    // Use this for initialization
    void Start()
    {
        XMoveSpeed = 0;
        ZMoveSpeed = 0;
    }

    // Update is called once per frame
    void Update()
    {
        this.GetComponent<Rigidbody>().velocity= new Vector3(0,0,0);
        this.transform.position = new Vector3(this.transform.position.x, 0, this.transform.position.z);
        this.transform.Translate(XMoveSpeed, 0f, ZMoveSpeed);

        Ray up = new Ray();
        up.origin = this.transform.position;
        up.direction = Vector3.forward;

        Ray down = new Ray();
        down.origin = this.transform.position;
        down.direction = Vector3.back;

        Ray left = new Ray();
        left.origin = this.transform.position;
        left.direction = Vector3.left;

        Ray right = new Ray();
        right.origin = this.transform.position;
        right.direction = Vector3.right;

        if (XMoveSpeed == 0 && ZMoveSpeed == 0 && UI.winwin != 1)
        {
            if (Input.GetMouseButtonDown(0))
            {
                if (EventSystem.current.currentSelectedGameObject != null)
                { }
                else
                {
                    lastPoint = Input.mousePosition;
                }
            }
            if (Input.GetMouseButtonUp(0))
            {
                zhaung = 0;
                Vector3 thisPoint = Input.mousePosition;
                xx = thisPoint.x - lastPoint.x;
                yy = thisPoint.y - lastPoint.y;
                System.Math.Abs(xx);
                System.Math.Abs(yy);
                if (xx < 0)
                {
                    xx = -xx;
                }
                if (yy < 0)
                {
                    yy = -yy;
                }
                if (thisPoint.x - lastPoint.x > 0 && xx > yy && !Physics.Raycast(right, 0.6375737f))
                {
                    XMoveSpeed = 0.1f;
                }
                else if (thisPoint.x - lastPoint.x <= 0 && xx > yy && !Physics.Raycast(left, 0.6375737f))
                {
                    XMoveSpeed = -0.1f;
                }
                else if (thisPoint.y - lastPoint.y > 0 && xx < yy && !Physics.Raycast(up, 0.6375737f))
                {
                    ZMoveSpeed = 0.1f;
                }
                else if (thisPoint.y - lastPoint.y <= 0 && xx < yy && !Physics.Raycast(down, 0.6375737f))
                {
                    ZMoveSpeed = -0.1f;
                }
            }
        }
        if (zhaung == 1)
        {
            this.transform.position = new Vector3(Ground.Last.x, 0, Ground.Last.z);
            XMoveSpeed = 0;
            ZMoveSpeed = 0;
        }
    }

    void OnCollisionEnter(Collision other)
    {
        if (other.collider.tag == "Wall")
        {
            zhaung = 1;
        }
    }
}
