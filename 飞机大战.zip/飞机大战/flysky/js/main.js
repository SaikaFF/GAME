// JavaScript Document
var mainDiv=document.getElementById("maindiv");//获得主界面
var startdiv=document.getElementById("startdiv");//获得开始界面
var scorediv=document.getElementById("scorediv");//获得游戏中分数显示界面
var scorelabel=document.getElementById("label");//获得分数界面
var suspenddiv=document.getElementById("suspenddiv");//获得暂停界面
var enddiv=document.getElementById("enddiv");//获得游戏结束界面
var planscore=document.getElementById("planscore");//获得游戏结束后分数统计界面
var scores=0;//初始化分数
var a=5;//子弹强度控制
var b=5;//敌机数量控制

//创建飞机类
function plan(hp,X,Y,sizeX,sizeY,score,dietime,sudu,boomimage,imagesrc){
    this.planX=X;
    this.planY=Y;
    this.imagenode=null;
    this.planhp=hp;
    this.planscore=score;
    this.plansizeX=sizeX;
    this.plansizeY=sizeY;
    this.planboomimage=boomimage;
    this.planisdie=false;
    this.plandietimes=0;
    this.plandietime=dietime;
    this.plansudu=sudu;
//行为
/*
移动行为
     */
    this.planmove=function(){
        if(scores<=50000){
            this.imagenode.style.top=this.imagenode.offsetTop+this.plansudu+"px";
        }
        else if(scores>50000&&scores<=100000){
            this.imagenode.style.top=this.imagenode.offsetTop+this.plansudu+1+"px";
        }
        else if(scores>100000&&scores<=150000){
            this.imagenode.style.top=this.imagenode.offsetTop+this.plansudu+2+"px";
        }
        else if(scores>150000&&scores<=200000){
            this.imagenode.style.top=this.imagenode.offsetTop+this.plansudu+3+"px";
        }
        else if(scores>200000&&scores<=300000){
            this.imagenode.style.top=this.imagenode.offsetTop+this.plansudu+4+"px";
        }
		else if(scores>300000&&scores<=500000){
            this.imagenode.style.top=this.imagenode.offsetTop+this.plansudu+5+"px";
        }
        else{
            this.imagenode.style.top=this.imagenode.offsetTop+this.plansudu+10+"px";
        }
    }
    this.init=function(){
        this.imagenode=document.createElement("img");
        this.imagenode.style.left=this.planX+"px";
        this.imagenode.style.top=this.planY+"px";
        this.imagenode.src=imagesrc;
        mainDiv.appendChild(this.imagenode);
    }
    this.init();
}

/*
创建子弹类
 */
function bullet(X,Y,sizeX,sizeY,imagesrc){
    this.bulletX=X;
    this.bulletY=Y;
    this.bulletimage=null;
    this.bulletattach=1;
    this.bulletsizeX=sizeX;
    this.bulletsizeY=sizeY;
//行为
/*
 移动行为
 */
    this.bulletmove=function(){
        this.bulletimage.style.top=this.bulletimage.offsetTop-60+"px";
    }
    this.init=function(){
        this.bulletimage=document.createElement("img");
        this.bulletimage.style.left= this.bulletX+"px";
        this.bulletimage.style.top= this.bulletY+"px";
        this.bulletimage.src=imagesrc;
        mainDiv.appendChild(this.bulletimage);
    }
    this.init();
}

/*
 创建单行子弹类
 */
function oddbullet(X,Y){
    bullet.call(this,X,Y,6,14,"image/bullet1.png");
}

/*
创建敌机类
 */
function enemy(hp,a,b,sizeX,sizeY,score,dietime,sudu,boomimage,imagesrc){
    plan.call(this,hp,random(a,b),-200,sizeX,sizeY,score,dietime,sudu,boomimage,imagesrc);
}
//产生min到max之间的随机数
function random(min,max){
    return Math.floor(min+Math.random()*(max-min));
}

/*
创建本方飞机类
 */
function ourplan(X,Y){
    var imagesrc="image/我的飞机.gif";
    plan.call(this,1,X,Y,66,80,0,660,0,"image/本方飞机爆炸.gif",imagesrc);
    this.imagenode.setAttribute('id','ourplan');
}

//创建本方飞机
var selfplan=new ourplan(360,485);
//移动事件
var ourPlan=document.getElementById('ourplan');
var yidong=function(){
	var oevent=window.event||arguments[0];
	var selfplanX=oevent.clientX;
	var selfplanY=oevent.clientY;
	ourPlan.style.left=selfplanX-selfplan.plansizeX/2+"px";
	ourPlan.style.top=selfplanY-selfplan.plansizeY/2+"px";
}

//暂停事件
var number=0;
var zanting=function(){
	if(number==0){
		suspenddiv.style.display="block";
		if(document.removeEventListener){
			mainDiv.removeEventListener("mousemove",yidong,true);
			bodyobj.removeEventListener("mousemove",bianjie,true);
		}
		else if(document.detachEvent){
			mainDiv.detachEvent("onmousemove",yidong);
			bodyobj.detachEvent("onmousemove",bianjie);
		}
		clearInterval(set);
		number=1;
	}
	else{
		suspenddiv.style.display="none";
		if(document.addEventListener){
			mainDiv.addEventListener("mousemove",yidong,true);
			bodyobj.addEventListener("mousemove",bianjie,true);
		}
		else if(document.attachEvent){
			mainDiv.attachEvent("onmousemove",yidong);
			bodyobj.attachEvent("onmousemove",bianjie);
		}
		set=setInterval(start,20);
		number=0;
	}
}

//边界事件
var bianjie=function(){
	var oevent=window.event||arguments[0];
	var bodyobjX=oevent.clientX;
	var bodyobjY=oevent.clientY;
	if(bodyobjX<5||bodyobjX>945||bodyobjY<0||bodyobjY>568){
		if(document.removeEventListener){
			mainDiv.removeEventListener("mousemove",yidong,true);
		}
		else if(document.detachEvent){
			mainDiv.detachEvent("onmousemove",yidong);
		}
	}
	else{
		if(document.addEventListener){
			mainDiv.addEventListener("mousemove",yidong,true);
		}
		else if(document.attachEvent){
			mainDiv.attachEvent("onmousemove",yidong);
		}
	}
}

//添加响应函数
var bodyobj=document.getElementsByTagName("body")[0];
if(document.addEventListener){
	mainDiv.addEventListener("mousemove",yidong,true);//添加移动
	selfplan.imagenode.addEventListener("click",zanting,true);//添加暂停
	bodyobj.addEventListener("mousemove",bianjie,true);//添加判断飞机移出边界事件
	suspenddiv.getElementsByTagName("button")[0].addEventListener("click",zanting,true);
	suspenddiv.getElementsByTagName("button")[1].addEventListener("click",youxishuoming,true);
	suspenddiv.getElementsByTagName("button")[2].addEventListener("click",jixu,true);
}
else if(document.attachEvent){
	mainDiv.attachEvent("onmousemove",yidong);
	selfplan.imagenode.attachEvent("onclick",zanting);
	bodyobj.attachEvent("onmousemove",bianjie);
	suspenddiv.getElementsByTagName("button")[0].addEventListener("onclick",zanting,true);
	suspenddiv.getElementsByTagName("button")[1].addEventListener("click",youxishuoming,true);
	suspenddiv.getElementsByTagName("button")[2].addEventListener("click",jixu,true);
}

//初始化变量
selfplan.imagenode.style.display="none";
var enemys=[];//敌机对象组
//子弹对象组
var bullets=[];
var mark=0;
var mark1=0;
var backgroundPositionY=0;

//start函数
function start(){
	mainDiv.style.backgroundPositionY=backgroundPositionY+"px";
	backgroundPositionY+=0.5;
	if(backgroundPositionY==568){
		backgroundPositionY=0;
	}
	mark++;
	//创建敌方飞机
	if(mark==20){
		mark1++;
		//中飞机
		if(mark1%b==0){
			enemys.push(new enemy(6,25,822,46,60,5000,360,random(1,3),"image/中飞机爆炸.gif","image/enemy3_fly_1.png"));
		}
		//大飞机
		if(mark1%(4*b)==0){
			enemys.push(new enemy(12,57,630,110,164,30000,540,1,"image/大飞机爆炸.gif","image/enemy2_fly_1.png"));
			mark1=0;
		}
		//小飞机
		else{
			enemys.push(new enemy(1,19,858,14,24,1000,360,random(1,5),"image/小飞机爆炸.gif","image/enemy1_fly_1.png"));
		}
		mark=0;
	}
	//移动敌方飞机
	var enemyslen=enemys.length;
	for(var i=0;i<enemyslen;i++){
		if(enemys[i].planisdie!=true){
			enemys[i].planmove();
		}
	//如果敌机超出边界,删除敌机
		if(enemys[i].imagenode.offsetTop>568){
			mainDiv.removeChild(enemys[i].imagenode);
			enemys.splice(i,1);
			enemyslen--;
		}
	//当敌机死亡标记为true时,经过一段时间后清除敌机
		if(enemys[i].planisdie==true){
			enemys[i].plandietimes+=20;
			if(enemys[i].plandietimes==enemys[i].plandietime){
				mainDiv.removeChild(enemys[i].imagenode);
				enemys.splice(i,1);
				enemyslen--;
			}
		}
	}
	if(scores>=100000)
	{
		a=4;
		b=4;
	}
	if(scores>=200000)
	{
		a=3;
		b=3;
	}
	if(scores>=300000)
	{
		a=2;
		b=2;
	}
	//创建子弹
	if(mark%a==0){
		if(a==4||a<=3)
		{
		bullets.push(new oddbullet(parseInt(selfplan.imagenode.style.left)+7,parseInt(selfplan.imagenode.style.top)+10));
		bullets.push(new oddbullet(parseInt(selfplan.imagenode.style.left)+55,parseInt(selfplan.imagenode.style.top)+10));
		}
		if(a==5||a<=3)
		{
		bullets.push(new oddbullet(parseInt(selfplan.imagenode.style.left)+31,parseInt(selfplan.imagenode.style.top)-10));
		}
	}
	//移动子弹
	var bulletslen=bullets.length;
	for(var i=0;i<bulletslen;i++){
		bullets[i].bulletmove();
		//如果子弹超出边界,删除子弹
		if(bullets[i].bulletimage.offsetTop<0){
			mainDiv.removeChild(bullets[i].bulletimage);
			bullets.splice(i,1);
			bulletslen--;
		}
	}
	//碰撞检测
	for(var k=0;k<bulletslen;k++){
        for(var j=0;j<enemyslen;j++){
            //判断碰撞本方飞机
            if(enemys[j].planisdie==false){
                if(enemys[j].imagenode.offsetLeft+enemys[j].plansizeX>=selfplan.imagenode.offsetLeft&&enemys[j].imagenode.offsetLeft<=selfplan.imagenode.offsetLeft+selfplan.plansizeX){
                  if(enemys[j].imagenode.offsetTop+enemys[j].plansizeY>=selfplan.imagenode.offsetTop+40&&enemys[j].imagenode.offsetTop<=selfplan.imagenode.offsetTop-20+selfplan.plansizeY){
                      //碰撞本方飞机，游戏结束，统计分数
                      selfplan.imagenode.src="image/本方飞机爆炸.gif";
                      enddiv.style.display="block";
                      planscore.innerHTML=scores;
                      if(document.removeEventListener){
                          mainDiv.removeEventListener("mousemove",yidong,true);
                          bodyobj.removeEventListener("mousemove",bianjie,true);
                      }
                      else if(document.detachEvent){
                          mainDiv.detachEvent("onmousemove",yidong);
                          bodyobj.removeEventListener("mousemove",bianjie,true);
                      }
                      clearInterval(set);
                  }
                }
                //判断子弹与敌机碰撞
                if((bullets[k].bulletimage.offsetLeft+bullets[k].bulletsizeX>enemys[j].imagenode.offsetLeft)&&(bullets[k].bulletimage.offsetLeft<enemys[j].imagenode.offsetLeft+enemys[j].plansizeX)){
                    if(bullets[k].bulletimage.offsetTop<=enemys[j].imagenode.offsetTop+enemys[j].plansizeY&&bullets[k].bulletimage.offsetTop+bullets[k].bulletsizeY>=enemys[j].imagenode.offsetTop){
                        //敌机血量减子弹攻击力
                        enemys[j].planhp=enemys[j].planhp-bullets[k].bulletattach;
                        //敌机血量为0，敌机图片换为爆炸图片，死亡标记为true，计分
                        if(enemys[j].planhp==0){
                            scores=scores+enemys[j].planscore;
                            scorelabel.innerHTML=scores;
                            enemys[j].imagenode.src=enemys[j].planboomimage;
                            enemys[j].planisdie=true;
                        }
                        //删除子弹
                        mainDiv.removeChild(bullets[k].bulletimage);
                            bullets.splice(k,1);
                            bulletslen--;
                            break;
                    }
                }
            }
        }
	}
}

//开始游戏按钮点击事件
var set;
function begin(){
	startdiv.style.display="none";
	mainDiv.style.display="block";
	selfplan.imagenode.style.display="block";
	scorediv.style.display="block";
	//调用开始函数
	set=setInterval(start,20);
}
//暂停界面游戏说明事件
function youxishuoming(){
	alert("该游戏一共有3种敌人,陨石、中型战机、大型战机，它们的生命值分别是1、6、12，相对应的，越强大的敌人击败后所获得的分数也越高。玩家战机每获得10万分攻击火力会获得加强,一共有2次。敌机当玩家分数达到一定程度会加快速度并加多中型、大型战机的数量，敌机速度分别有6个阶段，敌机数量分别有3个阶段，玩家分数达到50W分后会进入”地狱模式”。鼠标位置控制玩家飞机的位置,单击鼠标左键可以弹出暂停菜单。");
}
//游戏结束后点击继续按钮事件
function jixu(){
	location.reload(true);
}